library(rENA);

data(RS.data)

codes = c('Data',
          'Technical.Constraints',
          'Performance.Parameters',
          'Client.and.Consultant.Requests',
          'Design.Reasoning',
          'Collaboration')

units = c("UserName","Condition", "GroupName")
convo = c("Condition","GroupName")
meta = c("CONFIDENCE.Change","CONFIDENCE.Pre","CONFIDENCE.Post","C.Change")
window.type = "MovingStanzaWindow"
window.size = 10
group1 = "FirstGame"
group2 = "SecondGame"
groupCol = "Condition"

accum = ena.accumulate.data(
  units = RS.data[,c("Condition","UserName")],
  conversation = RS.data[,c("Condition","GroupName")],
  metadata = RS.data[,c("CONFIDENCE.Change","CONFIDENCE.Pre","CONFIDENCE.Post","C.Change")],
  codes = RS.data[,codes],
  model = "EndPoint",
  window.size.back = 4
)

set1 = ena.make.set(enadata = accum, rotation.by = ena.rotate.by.generalized, rotation.params = list(x_var = accum$connection.counts[, "Condition"]))
set2 = ena.make.set(enadata = accum, rotation.by = ena.rotate.by.generalized, rotation.params = list(x_var = accum$connection.counts[, c("Condition", "CONFIDENCE.Change")]))
set3 = ena.make.set(enadata = accum, rotation.by = ena.rotate.by.generalized, rotation.params = list(x_var = accum$connection.counts[, c("Condition", "CONFIDENCE.Change")], y_var = accum$connection.counts[, "CONFIDENCE.Change"]))
m0 = set1$points[, mean(GMR1), by = Condition]
m1 = set1$points[, mean(SVD2), by = Condition]
m2 = set2$points[,mean(SVD2),by = Condition]
m20 = set2$points[,mean(GMR1),by = Condition]
m3 = set3$points[,mean(GMR2),by = Condition]
m30 = set3$points[,mean(GMR1),by = Condition]
t(set1$rotation.matrix$GMR1)%*%set1$rotation.matrix$SVD2
t(set2$rotation.matrix$GMR1)%*%set2$rotation.matrix$SVD2
t(set3$rotation.matrix$GMR1)%*%set3$rotation.matrix$GMR2
