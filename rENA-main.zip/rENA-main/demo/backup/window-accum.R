f = "./inst/extdata/small-data/rs.data.sorted.csv";
fs = "./inst/extdata/small-data/rs.data.act13.grp1.csv";
df = read.csv(f)

unitsBy = c("UserName");
stanzasBy = c("ActivityNumber","GroupName");
codeNames = c("E.data","S.data","E.design","S.design","S.professional","E.client","V.client","E.consultant","V.consultant","S.collaboration","I.engineer","I.intern","K.actuator","K.rom","K.materials","K.power")

win.b = 4;
win.f = 1;

acc = ENAdata$new(
  f,
  units.by = unitsBy,
  conversations.by = stanzasBy,    #column names of conversation df, automatically accumulating by all cols for accum from dfs
  codes = codeNames,
  window.size.back = win.b,
  window.size.forward = win.f,
  weight.by = "binary",
  model = "EndPoint"
)
