devtools::load_all(".")
karin = read.csv("~/Downloads/1358FullResults/1358.csv", stringsAsFactors = F, check.names = T)
karin = read.csv("~/Downloads/1358 (3).csv", stringsAsFactors = F, check.names = T)
karin = openxlsx::read.xlsx("~/Downloads/1358-re.xlsx")
source('~/Workspaces/RStudio2/rENA/demo/backup/karin/karin-unit-groups.R')
source('~/Workspaces/RStudio2/rENA/demo/backup/karin/karin-units.R')
source('~/Workspaces/RStudio2/rENA/demo/backup/karin/karin-conv.R')

runIt <- function(in.par = F, include.meta = F) {
  # profvis::profvis({
    ena.generate(
      file = karin,
      window.size.back = 4,
      units.by = c('Condition','sex','speaker'),
      conversations.by = c('Participant','Condition'),
      # code = c('shame','sad','cold.hearted','grateful'),
      code = c('guilt', 'helpful', 'pride', 'relieved'),
      # code = c('ethnicity','helpful','pride','shame','guilt','relieved','Participant','angry','excited','sad','cold.hearted','grateful','good.friend','value.Friend','peers.approve','Condition','worried'),
      scale.nodes = T,
      unit.groups = unit.groups,
      sphere.norm = T,
      units.used = units.used,
      conversations.used = conversations.used,
      window = 'Conversation',
      weight.by = 'prod',
      fields = c('enadata$unit.names','enadata$metadata','enadata$units','rotation.set$rotation','node.positions','points.normed.centered','points.rotated','points.rotated.scaled','line.weights','enadata$codes','enadata$adjacency.matrix','correlations','variance'),
      weight.network.by = 'mean',
      s3.url = 's3://rena-data-files/google:115244317706686998972/NewSelections/1358 (2).csv'
      ,include.meta = include.meta
      ,keep.dimensions = c("SVD1","SVD2")
      ,in.par = in.par
      ,grainSize = 1
    )
  # })
}
#
 microbenchmark::microbenchmark(
   a = runIt(in.par = F, include.meta = T),
   b = runIt(in.par = F, include.meta = F),
   times=10
 )

# RcppParallel::setThreadOptions(numThreads = 4)
profvis::profvis({
  d = runIt(in.par = T)
})
# ref_window_df(dfDT_codes[1:5, codes, with = F])
#
#
# df = data.frame(a = c(1,0,1,0), b = c(0,0,1,0), c = c(1,1,1,1))

codes = c('ethnicity','sad','cold.hearted','grateful')
data = rbind(karin[,codes], karin[,codes])
data = rbind(data, data)
microbenchmark::microbenchmark(
  par_kar100 = try_one(data, 4, binary = F, grainSize = 100),
  par_kar100b = try_one(data, 4, binary = T, grainSize = 100),
  # par_kar10 = try_one(data, 4, binary = F, grainSize = 10),
  par_kar1 = try_one(data, 4, binary = F, grainSize = 1),
  par_kar1b = try_one(data, 4, binary = T, grainSize = 1),
  reg_kar = ref_window_df(data, windowSize = 4, binary = F),
  reg_karb = ref_window_df(data, windowSize = 4, binary = T),
  times = 100

)


set.gend = runIt(T)
