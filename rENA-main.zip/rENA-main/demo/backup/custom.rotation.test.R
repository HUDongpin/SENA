non.proj = ena.generate(
  Set1$enadata$raw,
  window.size.back = 4,
  units.by = Set1$enadata$function.params$units.by,
  conversations.by = Set1$enadata$function.params$conversations.by,
  code = Set1$enadata$codes,
  scale.nodes = T,
  sphere.norm = T,
  window='Moving',
  weight.by ='binary',
  fields =c('enadata$unit.names','enadata$units','node.positions','points.normed.centered','points.rotated','line.weights','enadata$codes','enadata$adjacency.matrix','correlations','variance'),
  weight.network.by ="mean"
  # ,rotation.matrix = rotMat
)

rotMat = list(
  'name' = 'Set1',
  rotation = list(
    # 'rotation' = matrix(c(-0.38708,-0.04283,-0.45169,0.04927,0.29967,0.42526,-0.30823,-0.44673,0.00848,0.10821,-0.04274,-0.08574,0.17137,-0.15555,-0.04627,0.20987,0.46971,-0.31,-0.21013,0.03573,-0.31807,0.24653,-0.3194,0.51305,-0.11662,0.03654,0.00596,0.20901,0.00043,-0.08917,-0.11494,0.10593,0.15082,-0.64922,-0.01546,-0.0468,0.13853,-0.08508,-0.45404,-0.06663,0.13052,-0.04562,0.17676,-0.48511,0.07873,-0.02786,0.20459,0.31198,0.05292,0.31618,-0.1008,-0.54295,0.16764,0.27049,-0.19004,0.1356,0.39545,-0.05634,-0.3653,-0.05946,-0.25452,0.11762,0.22899,0.11461,0.20959,0.20013,0.21746,0.27994,0.07897,-0.03822,0.37371,-0.05319,0.64259,0.27556,0.08445,0.03042,0.2102,0.29911,-0.02772,0.36598,-0.09642,-0.16636,-0.01653,-0.01514,-0.1584,-0.41445,-0.68611,-0.03978,0.11343,0.10581,0.24682,-0.04554,-0.3738,0.44655,0.15888,-0.04434,0.19861,0.2444,-0.19034,-0.39111,0.15041,-0.21694,0.03566,-0.45882,0.02863,-0.11953,-0.6814,0.22629,0.03946,-0.05336,-0.28948,0.08947,-0.19294,0.39978,0.00025,-0.06804,-0.14574,0.2497,-0.29438,0.04545,0.53287,0.11564,0.22597,0.07385,-0.36997,0.54113,-0.12831,-0.09844,0.13396,0.10054,-0.11967,-0.08509,0.28097,-0.2398,0.06515,0.04032,0.12958,0.37112,0.29199,0.34702,0.11091,0.46728,-0.40353,-0.03881,0.29082,0.15828,0.08813,-0.31719,-0.15863,0.00283,-0.2483,0.20571,-0.12524,0.08471,0.01142,-0.03586,0.21933,0.36291,0.11141,0.37342,-0.5552,0.18863,0.09328,-0.28179,0.32887,-0.50722,0.18999,0.15104,0.09418,-0.418,0.25141,0.20184,-0.0437,0.19138,-0.50795,-0.09066,-0.06411,-0.24271,-0.10115,-0.13517,-0.16298,0.1735,-0.05613,0.02562,-0.23635,-0.11171,-0.15649,0.22071,0.1807,0.49691,0.42888,-0.48275,-0.18431,-0.20908,-0.1541,-0.02156,0.05716,0.09449,0.14604,-0.00268,-0.12813,0.04588,0.03794,-0.21515,0.12428,-0.28518,0.04712,0.27307,-0.06485,-0.8497,-0.14036,0.24109,0.08712,0.43072,-0.33873,-0.41473,-0.23993,-0.36219,-0.32778,0.01063,0.04039,0.04814,0.24228,0.02893,0.2873), nrow =15),
    # 'node.positions'= matrix(c(-0.22544,1.05532,-2.51606,0.73471,1.50285,-0.02259,-1.90055,-1.70763,0.45304,-1.27034,0.20032,-0.0966,1.42667,1.60197,0.59449,-1.9322,-0.93204,0.1685,-0.4202,1.12127,2.14821,0.6194,1.84957,0.09878,1.38647,-1.23979,0.5356,1.66753,-0.75612,0.06917,-1.67338,1.57134,0.09266,1.24795,-1.73661,-0.48225), nrow =6)
    'rotation' = non.proj$set$rotation.set$rotation,
    'node.positions' = non.proj$set$rotation.set$node.positions
  ),
  # codes = c('Data','Technical.Constraints','Performance.Parameters','Client.and.Consultant.Requests','Design.Reasoning','Collaboration')
  codes = non.proj$set$rotation.set$codes
)

proj = ena.generate(
  Set1$enadata$raw,
  window.size.back = 4,
  units.by = c("Condition", "GroupName"), #Set1$enadata$function.params$units.by,
  conversations.by = Set1$enadata$function.params$conversations.by,
  code = Set1$enadata$codes,
  scale.nodes = T,
  sphere.norm = T,
  window='Moving',
  weight.by ='binary',
  fields =c('enadata$unit.names','enadata$units','node.positions','points.normed.centered','points.rotated','line.weights','enadata$codes','enadata$adjacency.matrix','correlations','variance'),
  weight.network.by ="mean"
  # ,rotation.matrix = list('rotation' = list(
  #     'rotation' = non.proj$set$rotation.set$rotation,
  #     'node.positions' = non.proj$set$rotation.set$node.positions
  #   ),
  #   'codes' = non.proj$set$rotation.set$codes
  # )
  ,rotation.matrix = rotMat
)
