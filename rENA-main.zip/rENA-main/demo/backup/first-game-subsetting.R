
first.game.trajs = df.set.traj.lws$enadata$trajectories$units$Condition == "FirstGame"
first.game.pts = df.set.traj.lws$points.rotated[first.game.trajs,]
first.game.users = df.set.traj.lws$enadata$trajectories$units$UserName[first.game.trajs]
sec.game.trajs = df.set.traj.lws$enadata$trajectories$units$Condition == "SecondGame"
sec.game.pts = df.set.traj.lws$points.rotated[sec.game.trajs,]
sec.game.users = df.set.traj.lws$enadata$trajectories$units$UserName[sec.game.trajs]


first.game = df.set.lws$enadata$units$Condition == "FirstGame"
first.game.pts = df.set.lws$points.rotated[first.game,]
first.game.users = df.set.lws$enadata$units$UserName[first.game]
first.game.mean.wts = colMeans(df.set.lws$line.weights[first.game,] )
sec.game = df.set.lws$enadata$units$Condition == "SecondGame"
sec.game.pts = df.set.lws$points.rotated[sec.game,]
sec.game.users = df.set.lws$enadata$units$UserName[sec.game]
sec.game.mean.wts = colMeans(df.set.lws$line.weights[sec.game,] )


amaliax = first.game.users == "amalia x"
luist = first.game.users == "luis t"
mitchellh = first.game.users == "mitchell h"
first.game.labels = df.set.traj.lws$enadata$units[first.game.trajs,]
first.game.label.txt = merge_columns_c(first.game.labels, cols = colnames(first.game.labels))


amalia.wts = colMeans((df.set.traj.lws$line.weights[first.game.trajs,])[amaliax,])
luis.wts = colMeans((df.set.traj.lws$line.weights[first.game.trajs,])[luist,])
mitch.wts = colMeans((df.set.traj.lws$line.weights[first.game.trajs,])[mitchellh,])
