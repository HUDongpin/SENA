data(RS.data)

codeNames = c('Data','Technical.Constraints','Performance.Parameters','Client.and.Consultant.Requests','Design.Reasoning','Collaboration');

rs_codes = RS.data[,codeNames]

RcppParallel::setThreadOptions(numThreads = 4)
rs_lots = rbind(rs_codes, rs_codes, rs_codes, rs_codes, rs_codes)

microbenchmark::microbenchmark(
  par_try = try_one(rs_codes, 7, binary = F),
  reg_try = ref_window_df(rs_codes, windowSize = 7, binary = F),
  times = 100
)
