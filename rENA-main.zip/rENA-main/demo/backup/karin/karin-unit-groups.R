fileName <- '~/Desktop/1358-unit-groups.json'
unit.groups = readChar(fileName, file.info(fileName)$size)
