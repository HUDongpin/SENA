###### Function for test code #####
my.plot = function(set, net = "both") {
  unitNames = set$enadata$units

  ### Subset rotated points and plot Conition 1 Group Mean
  Ind.after = unitNames$CCvsNon == "Ind.after"
  Ind.after.points = set$points.rotated[Ind.after,]
  Ind.after.names = unitNames$teacherpid[Ind.after]

  ### Subset rotated points and plot Condition 2 Group Mean
  other = unitNames$CCvsNon == "Other"
  other.points = set$points.rotated[other,]
  other.names = unitNames$teacherpid[other]

  ### get mean network plots
  Ind.after.lineweights = set$line.weights[Ind.after,]
  Ind.after.mean = colMeans(Ind.after.lineweights)

  other.lineweights = set$line.weights[other,]
  other.mean = colMeans(other.lineweights)

  subtracted.network = (Ind.after.mean - other.mean)

  ### get means
  Ind.after.mean.location = colMeans(Ind.after.points)
  other.mean.location = colMeans(other.points)

  Ind.after.ci = t.test(Ind.after.points, conf.level = 0.95)$conf.int
  other.ci = t.test(other.points, conf.level = 0.95)$conf.int

  dim1.test = t.test(Ind.after.points[,1], other.points[,1], conf.level = 0.95)
  dim2.test = t.test(Ind.after.points[,2], other.points[,2], conf.level = 0.95)

  if (net == "both"){
    print(dim1.test)
    print(fun_cohens.d(Ind.after.points[,1], other.points[,1]))
    print(dim2.test)
  }

  #plot both
  # plot.combined = ena.plot(set)
  #
  # if(net != "Other"){
  #   plot.combined = ena.plot.points(plot.combined, Ind.after.points, colors = "red")
  # }
  # if(net != "Ind.after"){
  #   plot.combined = ena.plot.points(plot.combined, other.points, colors = "blue")
  # }
  # if(net != "Other"){
  #   plot.combined = ena.plot.points(plot.combined, Ind.after.mean.location,
  #                                   shape = "square",
  #                                   label.font.size = 15,
  #                                   label.offset = "bottom right",
  #                                   point.size = 15,
  #                                   colors = "red")
  # }
  # if(net != "Ind.after"){
  #   plot.combined = ena.plot.points(plot.combined, other.mean.location,
  #                                   shape = "square",
  #                                   label.font.size = 15,
  #                                   point.size = 15,
  #                                   colors = "blue")
  # }
  #
  # if(net == "Ind.after"){
  #   plot.combined = ena.plot.network(plot.combined, network = Ind.after.mean)
  # } else if(net == "Ind.before"){
  #   plot.combined = ena.plot.network(plot.combined, network = other.mean, colors = "blue")
  # } else {
  #   plot.combined = ena.plot.network(plot.combined, network = subtracted.network)
  # }
  #
  # plot.combined
}

##### Test code to run #####

#Install libraries
#library("rhoR")
library("rENA")

#get data
file = read.csv("./inst/extdata/CCSS_all.csv", header = T, stringsAsFactors = F)

#rows = file$State.all %in% c("Ind.before", "Ind.after")
#Set model parameters

units = file[,c("CCvsNon", "teacherpid")]
conversation = file[,c("teacherpid", "Board_Name")]

#units = file[rows, c("State.all", "teacherpid")]
#conversation = file[rows,c("teacherpid", "Board_Name")]
codes = file[,c(
  "Counting_Cardinality",
  "Operations_Algebraic_Thinking",
  "Numbers_Operations",
  "Measurement_Data",
  "Geometry",
  "Fractions",
  "Expression_Equations",
  "Numbers_System",
  "Statistics_Probability",
  "Non_CCSS"
)]

window = "C"
window.size.back = NULL

#Get regular ENA model
full = ena.accumulate.data(
  units = units,
  conversation = conversation,
  codes = codes,
  window = window,
  window.size.back = window.size.back
)

#Create EV model

#Get EVs
ev = ena.ev(
  units = units,
  conversation = conversation,
  codes = codes,
  window = window,
  window.size.back = window.size.back,
  runs=1000
)

#Create ENA sets
full.set = ena.make.set(
  enadata = full,
  rotation.by = ena.rotate.by.mean,
  rotation.params = list(
    full$metadata$CCvsNon == "Ind.after",
    full$metadata$CCvsNon == "Other"
    # full$metadata$State.all == "Ind.before",
    # full$metadata$State.all == "Ind.after"
  )
)

#make a copy of regular model
ev.model = full$clone(deep = TRUE)

#adjust adjacency vectors using means from expected value set
ev.model$adjacency.vectors = ev.model$adjacency.vectors / ev$adjacency.vectors
ev.model$adjacency.vectors[is.nan(as.matrix(ev.model$adjacency.vectors))] = 0

ev.set = ena.make.set(
  enadata = ev.model,
  rotation.by = ena.rotate.by.mean,
  rotation.params = list(
    full$metadata$CCvsNon == "Ind.after",
    full$metadata$CCvsNon == "Other"
    # full$metadata$State.all == "Ind.before",
    # full$metadata$State.all == "Ind.after"
  )
)

my.plot(full.set)
my.plot(full.set, net="Ind.after")
my.plot(full.set, net="Other")
my.plot(ev.set)
my.plot(ev.set, net="Ind.after")
my.plot(ev.set, net="Other")
