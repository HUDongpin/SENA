library(qedata)

set_1 <- RS.data |>
  define(
    units = c("UserName", "Condition"),
    horizon = c("Condition", "GroupName", "ActivityNumber")
  ) |>
  accumulate()

set_2 <- RS.data |>
  define() |>
    units("UserName", "Condition") |>
    horizon("Condition", "GroupName", "ActivityNumber") |>
  accumulate()

# TRUE
all.equal(set_1$connection.counts, set_2$connection.counts)

set_3 <- RS.data |>
  define() |>
    units("UserName", "Condition") |>
    horizon("Condition", "GroupName", "ActivityNumber") |>
  accumulate(window.size.back = 10)

# FALSE
all.equal(set_2$connection.counts, set_3$connection.counts)
