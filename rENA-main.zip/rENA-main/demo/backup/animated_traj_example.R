
data("RS.data")
units = c("UserName", "Condition")
conversation = c("ActivityNumber", "GroupName")
codes = c("Data", "Technical.Constraints", "Performance.Parameters",
            "Client.and.Consultant.Requests", "Design.Reasoning",
            "Collaboration")

set_end <- RS.data |>
  ena(
    units = units,
    conversation = conversation,
    codes = codes,
    window.size.back = 4,
    include.plots = FALSE
  );

set_end |> plot() |>
  add_points(Condition$FirstGame, colors = "blue") |>
  add_points(Condition$SecondGame, colors = "red") |>
  show()

set_traj <- as_trajectory(set_end)

set_traj <- plot(set_traj);
set_traj$plots[[1]]$plotted$points[[1]] <- list(color = "blue", data = set_traj$points$Condition$FirstGame)
set_traj$plots[[1]]$plotted$points[[2]] <- list(color = "red", data = set_traj$points$Condition$SecondGame)
set_traj |> with_trajectory(by = set_traj$`_function.params`$conversation[[1]]) |> show()

set_traj <- ena(RS.data,
    units = units,
    conversation = conversation,
    codes = codes,
    window.size.back = 4,
    include.plots = FALSE,
    model = "S"
  )  |>
  plot() |>
  add_points(Condition$FirstGame, colors = "blue") |>
  add_points(Condition$SecondGame, colors = "red") |>
  show()

set_traj |>
  plot() |>
  add_points(Condition$FirstGame, colors = "blue") |>
  add_points(Condition$SecondGame, colors = "red") |>
  with_trajectory(by = set_traj$`_function.params`$conversation[[1]]) |>
  show()

tmp <- set_traj |> plot() |>
    add_points(Condition$FirstGame)  |>
    add_points(Condition$SecondGame) |>
    with_trajectory(by = "ActivityNumber") |>
    show()

accum <- rENA:::ena.accumulate.data.file(
    RS.data, units.by = c("UserName", "Condition"),
    conversations.by = c("ActivityNumber", "GroupName"),
    codes = codes,
    model = "A"
  );
  newset <- ena.make.set(accum)

  newplot <- plot(newset) |> add_trajectory("ENA_UNIT")


game1.endpoints <- newset$points
