rm(list=ls())

devtools::build()
library(rENA)


data(RS.data)

#add warning message for using a grouping var not in units or metadata
#add conditional for plotting points and means


codes = c('Data',
          'Technical.Constraints',
          'Performance.Parameters',
          'Client.and.Consultant.Requests',
          'Design.Reasoning',
          'Collaboration')

units = c("UserName","Condition", "GroupName")
convo = c("Condition","GroupName")
meta = c("CONFIDENCE.Change","CONFIDENCE.Pre","CONFIDENCE.Post","C.Change")
window.type = "MovingStanzaWindow"
window.size = 10
group1 = "FirstGame"
group2 = "SecondGame"
groupCol = "Condition"

set = ena.accumulate.data(
        units = RS.data[,c("Condition","UserName")],
        conversation = RS.data[,c("Condition","GroupName")],
        metadata = RS.data[,c("CONFIDENCE.Change","CONFIDENCE.Pre","CONFIDENCE.Post","C.Change")],
        codes = RS.data[,codes],
        model = "EndPoint",
        window.size.back = 4
      ) |>
        ena.make.set()

plot(set) |>
  add_points()

plot(set) |>
  add_network(Condition$FirstGame) |>
  add_network(Condition$SecondGame, colors = "red")

plot(set) |>
  add_points(Condition$FirstGame, colors = "blue") |>
  add_points(Condition$SecondGame, colors = "red", mean = list(point.size = 10))

plot(set) |>
  add_network(Condition$FirstGame - Condition$SecondGame)


plot(set) |>
  add_points(as.matrix(set$points)[set$meta.data[["Condition"]] == "FirstGame",])


plot(set) |>
        add_points(Condition$FirstGame, mean = T, colors = "blue") |>
        add_points(Condition$SecondGame, mean = T, colors = "red") |>
        add_network(Condition$FirstGame - Condition$SecondGame, colors = c("blue", "red"))
