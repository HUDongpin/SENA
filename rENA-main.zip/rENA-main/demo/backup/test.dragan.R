library(rENA)

#############################################################################
## start from the dataset with trace data organized into sessions and with
## associate time management data (ie study modes derived from student time
## management practices)
#############################################################################



trace.data <- readRDS(file = "/Volumes/GoogleDrive/My Drive/Development/Workspaces/R/Dragan/Data/coded_trace_data.RData")

units = c("USER_ID","SESSION_ID")
conversation = c("USER_ID","SESSION_ID","WEEK", "TOPIC")
codeNames = c('CONTENT_ACCESS','FA_CO','FA_IN','FA_SR','SA_CO','SA_IN') #,'MC_EVAL')#,'MC_ORIENT','VIDEO_PA','VIDEO_PL');

## Initialize an ENAdata object, processing conversations from coded data to generate
## adjacency (co-occurrence) vectors

# microbenchmark::microbenchmark(
  accum = rENA::ena.accumulate.data(
    units = data.frame(trace.data[,units]),
    conversation = data.frame(trace.data[,conversation]),
    codes = trace.data[,codeNames],
    window.size.back = 5,
    # window = "Conversation",
    model = "EndPoint"
  )
  # , times = 1
# )

set = rENA::ena.make.set(
  enadata = accum
)
