###
ena.rotation.hena<-function(enaset,value_vars,x_var,y_var=NULL,control_vars=NULL,centering=TRUE,include_xy=FALSE){
    #
    # enaset: the set contains points for projection
    # value_vars: the variable names for points, all should be numeric
    # x_var: variable for x-axis,should be dichotomous factor or numeric
    # y_var: variable for y-axis, should be dichotomous factor or numeric, can be NULL
    # control_vars: a set of control variables, each of which could be factor or numeric
    # centering: TRUE/FALSE, centering x and y when it is TRUE.
    # include_xy: include interaction term xy in the model when it is TRUE.
    #
    #
  # get centered data
    if (!is.null(enaset$model$points.for.projection)) {
      data <- enaset$model$points.for.projection
    }else {
      data <- enaset$points.normed.centered
    }
    data<-as.data.frame(data)
    # browser()
    data[,value_vars] <- scale(as.matrix(data[,value_vars]), scale = F, center = T);
    # print(head(scale(as.matrix(data[,value_vars], scale = F, center = T))))

  # dummy code x_var
    if(!is.numeric(data[[x_var]]))
    {
      x_types = unique(data[[x_var]])
      if(length(x_types)!=2)
      {
        stop("Unable to rotate - x_var needs to be dichotomous or numeric.")
      }
      x_var_f = paste0(x_var,"_f")
      data[[x_var_f]]=ifelse(data[[x_var]]==x_types[1],0,1)
      x_var=x_var_f
    }

  # dummy code y_var
    if(!is.null(y_var))
    {
      if(!is.numeric(data[[y_var]]))
      {
        y_types = unique(data[[y_var]])
        if(length(y_types)!=2)
        {
          stop("Unable to rotate - y_var needs to be dichotomous or numeric.")
        }
        y_var_f = paste0(y_var,"_f")
        data[[y_var_f]]=ifelse(data[[y_var]]==y_types[1],0,1)
        y_var=y_var_f
      }
    }

  # centering x_var and y_var
    if(centering)
    {
      data[[x_var]]<-data[[x_var]]-mean(data[[x_var]])
      if(!is.null(y_var))
      {
        data[[y_var]]<-data[[y_var]]-mean(data[[y_var]])
      }
    }
    # browser()
  # prepare regression formula
    v=matrix(0,nrow=length(value_vars),ncol=2)
    f = x_var;
    if(!is.null(y_var))
    {
      f=paste(f,"+",y_var)
    }
    for(control in control_vars)
    {
      f=paste(f,"+",control)
    }
    if(include_xy)
    {
      xy_var=paste0(x_var,"_",y_var)
      data[[xy_var]]=data[[x_var]]*data[[y_var]]
      f=paste(f," + ",xy_var)
    }

    # run regression models and get slope variables
    for(i in 1:length(value_vars))
    {
      name = value_vars[i]
      formula = as.formula(paste0("data$`",name,"` ~ ",f))
      # print(formula)
      model<-lm(formula,data=data)
      v[i,1]=model$coefficients[2]
      if(!is.null(y_var))
      {
        v[i,2]=model$coefficients[3]
      }
    }

    # Normalize x rotation vector
    R=NULL
    vcount=0
    A<-as.data.frame(data)[value_vars]
    v1 = v[,1]
    norm_v1=sqrt(sum(v1*v1))
    if(norm_v1!=0)
    {
      v1=v1/norm_v1
      R=v1
      vcount=vcount+1
    }

    # Normalize y rotation vector, if applicable
    v2=NULL
    if(!is.null(y_var))
    {
      v2=v[,2]
      v2=v2-(t(v2)%*%v1)*v1
      norm_v2=sqrt(sum(v2*v2))
      if(norm_v2!=0)
      {
        v2=v2/norm_v2
        if(is.null(R))
        {
          R=v2
        }
        else
        {
          R=cbind(R,v2)
        }
        vcount=vcount+1
      }
    }

  # get svd for deflated points

    defA = as.matrix(A) - as.matrix(A)%*%v1%*%t(v1)
    if(!is.null(y_var))
    {
      defA = defA - defA%*%v2%*%t(v2)
    }
    svd_3 = svd(defA)
    svd_v= svd_3$v

    # Merge rotation vectors
    R = cbind(R,svd_v[,1:(ncol(svd_v)-vcount)])
    # AR = as.matrix(A)%*%R
    if(vcount==0)
    {
    colnames(R) <- c(
      paste0("SVD", as.character(1:ncol(R)))
    )
    } else if (vcount==1)
    {
      colnames(R) <- c(paste0("x_",x_var),
        paste0("SVD", as.character(2:ncol(R)))
      )
    } else
    {
      colnames(R) <- c(paste0("x_",x_var),paste0("y_",y_var),
                        paste0("SVD", as.character(3:ncol(R)))
      )
    }

    # put into ENARotationSet

    rotation_set <- ENARotationSet$new(
      node.positions = NULL,
      rotation = R,
      codes = enaset$codes
    )
    return(rotation_set)
}
#
#
# ### Test block begin
# codeNames = c("Data","Technical.Constraints","Performance.Parameters","Client.and.Consultant.Requests","Design.Reasoning","Collaboration")
# accum = ena.accumulate.data(
#   units = RS.data[,c("Condition","UserName","GameHalf")],
#   conversation = RS.data[,c("Condition","GroupName","GameHalf")],
#   metadata = RS.data[,c("CONFIDENCE.Change","CONFIDENCE.Pre","CONFIDENCE.Post","C.Change")],
#   codes = RS.data[,codeNames],
#   model = "EndPoint",
#   window.size.back = 4
# );
# set = ena.make.set(
#   enadata = accum,
#   rotation.by = ena.rotate.by.mean,
#   rotation.params = list(FirstGame=accum$meta.data$Condition=="FirstGame", SecondGame=accum$meta.data$Condition=="SecondGame")
# );
# value_variables=colnames(set$model$points.for.projection)[9:23]
#
# # Test 1 begin
# x_variable="Condition"
# test_set1 =ena.rotation.hena(enaset = set,value_vars = value_variables,x_var=x_variable)
# # Test 1 end
#
# # Test 2 begin
# y_variable = "GameHalf"
# test_set2=ena.rotation.hena(enaset = set,value_vars = value_variables,x_var=x_variable,y_var = y_variable)
# # Test 2 end
#
# # Test 3 begin
# # test_set3=ena.rotation.hena(enaset = set,value_vars = value_variables,x_var=x_variable,y_var = y_variable,include_xy = TRUE)
# # Test 3 ends
#
# # Test 4 begin
# controls = c("GameHalf")
# # test_set4=ena.rotation.hena(enaset = set,value_vars = value_variables,x_var=x_variable, control_vars = controls)
# # Test 4 ends
#
# ### Test block end
