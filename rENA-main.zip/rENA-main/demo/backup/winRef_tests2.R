dfDT_codes = data.table::copy(dfDT);
dfDT_codes$ENA_UNIT = merge_columns_c(dfDT_codes, cols=units.by, sep=".");
vL = length(codes);
adjacency.length = ( (vL * (vL + 1)) / 2) - vL ;
codedTriNames = paste("adjacency.code",rep(1:adjacency.length), sep=".");
temp1 = copy(dfDT_codes)
temp2 = copy(dfDT_codes)

setkeyv(temp1, units.by)

orig = temp1[,
 (codedTriNames) := ref_window_df(
   .SD[,.SD, .SDcols=codes, with=T],
   windowSize=window$back, windowForward=window$forward,
   binary = binary, binaryStanzas = binaryStanzas
 ),
 by=conversations.by,
 .SDcols=c(units.by, codes),
 with=T
];


one = temp2[,
  ref_window_df(
    .SD,
    windowSize=window$back, windowForward=window$forward,
    binary = binary, binaryStanzas = binaryStanzas
  ),
  by=conversations.by,
  .SDcols=codes,
  with=T
];

two = temp2[, .(), by=conversations.by]

library(RcppRoll)

myConv = as.matrix(temp1[seq.int(from=90,length.out=10),c(codeNames),with=F]);
print(myConv)
roll_sum(myConv, 2)


my_rolling_sum <- rollit_raw("
 double output = 1;
 for (int i=0; i < n; ++i) {
   sum = sum + X(i);
 }
 return output;")
