devtools::load_all(".")

df.file <- system.file("extdata", "rs.data.csv", package="rENA")

codeNames = c("E.data","S.data","E.design","S.design","S.professional","E.client","V.client","E.consultant","V.consultant","S.collaboration","I.engineer","I.intern","K.actuator","K.rom","K.materials","K.power");

## Test regular set
df.accum = ena.accumulate.data(
  df.file,
  units.by = c("UserName","Condition"),
  conversations.by = c("ActivityNumber","GroupName"),
  code.names = codeNames
);
df.accum.traj = ena.accumulate.data(
  df.file,
  units.by = c("UserName","Condition"),
  conversations.by = c("ActivityNumber","GroupName"),
  code.names = codeNames,
  trajectory.by = c("ActivityNumber"),
  trajectory.type = "accumulated"
);


#ENA_UNIT == "amelia n.FirstGame"
code.cols = colnames(df.accum$data.units.summed)[grep(pattern = "^adjacency", colnames(df.accum$data.units.summed))]

df.accum$data.units.summed[,c("ENA_UNIT",code.cols), with=F]

df.accum.traj$data.units.summed[,c("ENA_UNIT","ActivityNumber",code.cols), with=F]
