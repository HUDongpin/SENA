test.matrix = matrix(1:12, ncol=2)
test.df = data.frame(test.matrix)
test.df$condition = rep_len(LETTERS[1:2], nrow(test.df))
test.df$meta.stuff = rep_len(LETTERS[3:4], nrow(test.df))

rotate.one = function(data, to.add) {
  data + to.add
}
rotate.two = function(data, to.sub) {
  data - to.sub
}
egr.mean = function(data, ...) {
  # rows, dimIndex
  ## data[,dimIndex] = mean(data[rows, dimIndex])
  ## return(data)

  arguments = unlist(as.list(substitute(list(...)))[-1L], recursive = F)
  mean.by = arguments$by;

  cols = c("X1","X2");
  if(!is.null(arguments$columns)) {
    cols = arguments$columns;
  }

  # browser()
  data.dt = as.data.table(data);
  data.dt = lapply(names(mean.by), function(m) {
    data.dt = data.dt[, lapply(.SD, function(x) { x + 1}) ,by=c(m), .SDcols=cols]
  })
  as.data.frame(data.dt)
}
egr.svd = function(data, ...) {
  ## rows, dimIndex
  # pca(data[rows, dimIndex:ncol(data)])
}
egr.rotate = function(data, ...) {
  data
}
call.rotate = function(data, FUN, ...) {
  for(i in 1:length(FUN)) {
    this.method = names(FUN)[[i]]
    this.call = this.method[[1]]
    this.args = FUN[[i]]; #this.method[2:length(this.method)]
    newdata = do.call(this.call, list(data, this.args))
    # browser()

    if(all.equal(dim(newdata), dim(data)) != F) {
      stop(paste("Dimensions of the rotated data using", this.method,"did not much the original."))
    } else {
      data = newdata;
    }
  }

  data
}


  ### Subset ahead of time
  rotate.by = list(
    "egr.mean" = list(which(set$meta$group %in% c("A","B"))),
    "egr.mean" = which(set$meta$group %in% c("A","B")), # if we only care about rows of centered data, no list needed
    "egr.svd" = list()
  )

  ### Passing data along
  rotate.by = list(
    # Dimension 1
    # "egr.svd"

    c("egr.mean", "condition" = c("A","B")),
    "egr.mean" = list(by = list("condition"=c("A","B"))),

    # Dimension 2
    "egr.svd" = list()
  )

  #list(FUN = "egr.mean", params=list("condition" = c("A","B")))
  rotate.by = list(
    c(FUN = "egr.mean", list("condition" = c("A","B")))
  )


set$data$normed.centered$condition %in% c("A","B")

rotated = call.rotate(test.df, rotate.by)
print(rotated)
