library(rENA)
data(RS.data)

RS.data <- data.table::as.data.table(RS.data)

codes = c('Data','Technical.Constraints','Performance.Parameters','Client.and.Consultant.Requests','Design.Reasoning','Collaboration');
units = c("Condition", "UserName");
conversation = c("Condition","GroupName");


oldaccum = ena.accumulate.data(
  units = RS.data[,units],
  conversation = RS.data[,conversation],
  codes = RS.data[,codes],
  window.size.back = 4
)
oldset = ena.make.set(
  enadata = oldaccum
)

enaset <- RS.data |>
 accumulate(units, codes, conversation) |>
 model()

enaset <- RS.data |>
  accumulate(units, codes, conversation) |>
  sphere_norm() |>
  center() |>
  rotate()

enaset <- RS.data |>
  accumulate(units, codes, conversation) |>
  sphere_norm() |>
  center() |>
  rotate() |>
  project() |>
  optimize()


RS.data |>
  accumulate(units, codes, conversation) |>

  sphere_norm() |>
  center() |>
  rotate() |>
  project() |>

  optimize() |>
    plot() |>
      add_network() |>
      add_group(Condition$FirstGame) |>
      add_group(Condition$SecondGame);

RS.data |>
  accumulate(units, codes, conversation, window.size.back = 10) |>
  model() |>
    # move_nodes_to_unit_circle() |>
    move_nodes_to_unit_circle_with_equal_space() |>

    plot() |>
      add_group(Condition$FirstGame) |>
      add_group(Condition$SecondGame) |>
      add_network()


new_model <- RS.data |>
  accumulate(units, codes, conversation) |>

  sphere_norm() |>
  center() |>
  rotate() |>
  project() |>
  optimize();

new_model |> plot() |>
    add_network() |>
    add_group(Condition$FirstGame) |>
    add_group(Condition$SecondGame);
