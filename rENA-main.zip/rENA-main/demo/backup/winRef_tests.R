utts = matrix(
  c(c(1,0,0,1),
  c(0,1,0,0),
  c(1,0,0,1),
  c(0,0,0,0)),
  ncol = 4, nrow = 4
)
utts

# zoo::rollapply(utts, 2, sum, partial=T, align="right")
# zoo::rollapply(utts, 2, function(x) {
#   cat("X: ", x, "\n")
#
#   c(sum(x), sum(x[length(x)-1]))
# }, partial=T, align="r")
#
#
# windWrefs = zoo::rollapply(utts, 2, function(x) {
#   c(sum(x), sum(x[length(x)-1]))
# }, partial=T, align="r")

# wind = windWrefs[,1:(ncol(windWrefs)/2)]
# refs = windWrefs[,(ncol(windWrefs)/2):ncol(windWrefs)]
# windSums = colSums(wind)
# refsSums = colSums(refs)
#
#
# windWrefs2 = zoo::rollapply(utts, 2, function(x) {
#   c(sum(x), sum(x[length(x)-1]))
# }, partial=T, align="r")

# zoo_win <- function(utts, window = 1) {
#   winds = zoo::rollapply(utts, window, sum, partial=T, align="r")
#   refs = zoo::rollapply(utts, window, function(x) {
#     sum(x[1:length(x)-1])
#   }, partial=T, align="r")
#   t(apply(winds, 1, vector_to_ut2)) - t(apply(refs, 1, vector_to_ut2))
# }
# ttr_win <- function(utts, window = 1) {
#   utts2 = rbind(matrix(rep(0, ncol(utts)), nrow=(window-1), ncol=ncol(utts)), as.matrix(utts))
#   tt = apply(utts2, 2, function(x) {
#     utts3 = c(rep(NA, window-(window-1)), x[1:window-1])
#     c(
#       na.omit(TTR::runSum(x, window, cumulative = F), window),
#       na.omit(TTR::runSum(x[1:(length(x)-1)], window-1, cumulative = F), window-1)
#     )
#   })
#   t(apply(tt[,c(seq(1,ncol(tt)-1,2),seq(2,ncol(tt),2))], 1, function(x) vector_to_ut2(head(x, length(x)/2)) - vector_to_ut2(tail(x,length(x)/2))))
# }

# rcpp_win <- function(utts, window = 1) {
#   # browser()
#   utts2 = rbind(matrix(rep(0, ncol(utts)), nrow=(window-1), ncol=ncol(utts)), as.matrix(utts))
#   winds = RcppRoll::roll_sum(utts2, n=window, partial = T)
#   # refs = RcppRoll::roll_sum(head(utts2 ,nrow(utts2)-1), n=window-1, partial = T)
#   refs = as.matrix(winds - utts);
#   # t(apply(winds, 1, vector_to_ut2)) - t(apply(refs, 1, vector_to_ut2))
#   # t(sapply(1:nrow(winds), function(x) vector_to_ut2(winds[x,]) - vector_to_ut2(refs[x,])))
#   # sapply(1:nrow(utts), function(x) vector_to_ut2(winds[x,]) - vector_to_ut2(refs[x,]))
#   windows_less_refs(winds, refs)
# }
rENA:::ref_window_df(utts, 4, binary = F)

# benchIt <- function(utts, window, times = 1) {
#   microbenchmark::microbenchmark(
#     # ttr_win(utts, window),
#     # rcpp_win(utts, window),
#     rENA:::ref_window_df(utts, windowSize = window, binary = F),
#     times = times
#   )
# }
