#' Perform shuffle of an ena set
#' @export
shuffle = function(
  units,
  conversation,
  codes,
  metadata = NULL
) {
  #make sure input is data frame
  units = as.data.frame( units )
  conversation = as.data.frame( conversation )
  codes = as.data.frame( codes )

  units.dt = data.table::data.table(units)


  if(!is.null(metadata)) {
    metadata = as.data.frame( metadata )
  }

  #pull unique units as data frame
  unique.units = as.data.frame( unique( units ) )

  # Add a unique ID to all of the units
  units.dt.ids = units.dt[, unitID := .GRP, by=c(colnames(units))]

  #loop over all unique units
  for ( i in 1:nrow(unique.units) ) {
    # Using data.table get all rows for this user
    this.unit.lines = units.dt.ids[unitID == i, which = T]

    # Randomize order using sample()
    shuffled.lines = sample(this.unit.lines, size = length(this.unit.lines), replace = F)

    conversation[this.unit.lines,] = conversation[shuffled.lines,]
    codes[this.unit.lines,] = codes[shuffled.lines,]
    metadata[this.unit.lines,] = metadata[shuffled.lines,]
  }

  out=list()
  out$units = units
  out$conversation = conversation
  out$metadata = metadata
  out$codes = codes

  return(out)
}

#' Public function to compute expected ENA values
#' @export
ena.ev = function(
  units,
  conversation,
  codes,
  metadata = NULL,
  window.size.back = 4,
  window = "S",
  runs = 10,
  levels = c(0.025, 0.975),
  silent = F
) {
  #set up parameters
  units=as.data.frame(units)
  conversation=as.data.frame(conversation)
  codes=as.data.frame(codes)
  if(!is.null(metadata)) metadata=as.data.frame(metadata)

  #create matrix to hold runs
  num.links = ncol(codes)*(ncol(codes)-1)/2

  accum.matrix = array(data = 0, dim = c(nrow(unique(units)), num.links, runs) )

  #loop to do the bootstrap (Cody can surely optimize)
  i = 1;
  for (i in 1:runs) {
    #shuffle data
    shuffled = shuffle(
      units = units,
      conversation = conversation,
      codes = codes,
      metadata = metadata
    )

    if(window == "C") {
      shuffled$conversation = conversation
    }

    #create accumulation
    this.accum = ena.accumulate.data(
      units = shuffled$units,
      conversation = shuffled$conversation,
      metadata = shuffled$metadata,
      codes = shuffled$codes,
      window = window,
      window.size.back = window.size.back,
      weight.by = "binary"
    )

    #store results
    accum.matrix[,,i] = as.array(as.matrix(this.accum$adjacency.vectors))

    #print status if requested
    if (!silent){
      cat("\r")
      cat(i)
    }
  }

  #compute mean for each unit
  avg.accum = apply(X = accum.matrix, FUN = mean, MARGIN = c(1,2))

  #compute sd for each unit
  sd.accum = apply(X = accum.matrix, FUN = sd, MARGIN = c(1,2))

  #Compute 95% confidence intervals (or specified confidence intervals)
  pcts.accum = apply(accum.matrix, 2, function(x){ quantile(x,levels) })

  #create output
  out=list()
  out$adjacency.vectors = avg.accum
  out$mean.ev = colMeans(avg.accum)
  out$percents = pcts.accum
  out$sd = colMeans(sd.accum)

  return(out)
}
