accum = ena.accumulate.data(
  units = RS.data[,c("Condition","UserName")],
  conversation = RS.data[,c("Condition","GroupName")],
  metadata = RS.data[,c("CONFIDENCE.Change","CONFIDENCE.Pre","CONFIDENCE.Post","C.Change")],
  codes = RS.data[,codeNames],
  model = "EndPoint",
  window.size.back = 4
);
set = ena.make.set(
  enadata = accum,
  rotation.by = ena.rotate.by.mean,
  rotation.params = list(FirstGame=accum$metadata$Condition=="FirstGame", SecondGame=accum$metadata$Condition=="SecondGame")
);

noExc = ena.conversations(
  RS.data,
  units=c("FirstGame.joseph k"),
  units.by=c('Condition','UserName'),
  conversation.by = c('ActivityNumber', 'GroupName'),
  codes = c( "Technical.Constraints", "Performance.Parameters" )
)

withExc = ena.conversations(
  RS.data,
  units=c("FirstGame.joseph k"),
  units.by=c('Condition','UserName'),
  conversation.by = c('ActivityNumber', 'GroupName'),
  codes = c( "Technical.Constraints", "Performance.Parameters" ),
  conversation.exclude = c('15.5')
)


coded = read.csv("~/Downloads/Coded-Slice3.csv")
codedExc = ena.conversations(
  coded,
  units=c("2.6300.2016-1"),
  units.by=c('difficulty','course','semester'),
  conversation.by = c('key'),
  codes = c( 'Con.plus', 'Gen.plus' ),
  conversation.exclude = c()
)

sally = read.csv("~/Downloads/Sally R mock dataset.csv")
sallyCon = ena.conversations(
  set = sally,
  units = c('1.medium.Teacherm L'),
  units.by = c('School','Level.of.Participation','Teacher'),
  codes = c('Instructional.Planning','Principal.Leadership'),
  conversation.by = c('School'),
  window = 4,
  conversation.exclude = c()
)

