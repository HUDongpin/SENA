adjMat1 = t(matrix(c(c(0.0,9.50714306,7.31993942,5.98658484),
                    c(0.0,0.0,0.58083612,8.66176146),
                    c(0.0,0.0,0.0,9.69909852),
                    c(0.0,0.0,0.0,0.0)), ncol=4))

adjMat2 = t(matrix(c(c(0.0,0.51686552,0.42544974,0.28684985),
                     c(0.0,0.0,0.28775159,0.36085276),
                     c(0.0,0.0,0.0,0.50650175),
                     c(0.0,0.0,0.0,0.0)),ncol=4))

adjMat1.ut = adjMat1[which(upper.tri(adjMat1))]
adjMat2.ut = adjMat2[which(upper.tri(adjMat2))]

adjMatrix = rbind(adjMat1.ut,adjMat2.ut)
rotMatrix = t(matrix(c(c(-1.86880248e+01,0.000000000e+00),
                     c(-9.60762555e-01,1.00752739e-14)), ncol=2))
