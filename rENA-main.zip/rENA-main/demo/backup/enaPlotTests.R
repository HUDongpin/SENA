unit.one = "devin c.FirstGame";
unit.two = "akash v.FirstGame";

ena.plot.network(enaset,
  selection.one.name = unit.one
)

ena.plot.network(enaset,
  selection.one.name = unit.two,
  selection.one.color = "#FF0000"
)

ena.plot.network(enaset,
  selection.one.name = unit.one,
  selection.two.name = unit.two
)
