# Loading Packages and Data ---------------------------------------------------------------------------------------

library(rENA)

library(parallel)
library(future)

data(RS.data)


# Default Parameters ----------------------------------------------------------------------------------------------
units = RS.data[,c("Condition","UserName")]
head(units)

conversation = RS.data[,c("Condition","GroupName")]
head(conversation)

codeCols = c(
  'Data','Technical.Constraints','Performance.Parameters',
  'Client.and.Consultant.Requests','Design.Reasoning','Collaboration'
)
codes = RS.data[,codeCols]

meta = RS.data[,c("CONFIDENCE.Change",
                  "CONFIDENCE.Pre","CONFIDENCE.Post","C.Change")]


# Functions -------------------------------------------------------------------------------------------------------
regen_model <- function(codes_to_use) {
  model <- ena.accumulate.data(
            units = units,
            conversation = conversation,
            codes = RS.data[, codes_to_use],
            metadata = meta,
            window.size.back = 4
          ) |> ena.make.set()
  return(unlist(ena.correlations(model)[, 1]))
}

gen_models <- function(min_code_count = 3) {
  all_models <- lapply(seq(length(codeCols) - 1, min_code_count), function(code_length) {
    code_combinations <- combn(codeCols, code_length)

    models_future <- future::future({apply(code_combinations, 2, function(code_comb) {
      regen_model(code_comb)
    })})

    # browser()
    # models <- sapply(models_future, future::value)
    models <- future::value(models_future)

    colnames(models) <- apply(code_combinations, 2, function(codes_to_use) {
      paste(which(codeCols %in% codes_to_use), collapse="_")
    })

    return(as.data.frame(t(models)))
  })

  all_models_table <- data.table::rbindlist(all_models)
  all_models_table[, codes := unlist(sapply(all_models, rownames))]

  return(all_models_table)
}


# Results ---------------------------------------------------------------------------------------------------------

model_zero = regen_model(codeCols)

future::plan(strategy = "sequential")
print(system.time({models_s = gen_models()}))

future::plan(strategy = "multisession", workers = 4)
print(system.time({models_p = gen_models()}))

