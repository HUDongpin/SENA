df.file <- system.file("extdata", "rs.data.csv", package="rENA")
codeNames = c("E.data","S.data","E.design","S.design","S.professional","E.client","V.client","E.consultant","V.consultant","S.collaboration","I.engineer","I.intern","K.actuator","K.rom","K.materials","K.power");

## Test regular set
df.accum = ena.accumulate.data(
  df.file,
  units.by = c("UserName","Condition"),
  conversations.by = c("ActivityNumber","GroupName"),
  code.names = codeNames
);
df.set.lws = ena.make.set(df.accum, position.method = lws.positions.es);
df.set.wes = ena.make.set(df.accum);

## Test Trajectory Set
df.accum.traj = ena.accumulate.data(
  df.file,
  units.by = c("UserName","Condition"),
  conversations.by = c("ActivityNumber","GroupName"),
  code.names = codeNames,
  trajectory.by = c("ActivityNumber"),
  trajectory.type = "accumulated"
);
df.set.traj.lws = ena.make.set(df.accum.traj, position.method = lws.positions.es);

## Plot units, one color, no variance
ena.plot.set(
  df.set.lws,
  plot.mode="units",
  units = df.set.lws$get.data("centered")$ENA_UNIT[1:10], #sample(df.set.lws$get.data("centered")$ENA_UNIT,10),
  unit.colors = I("red"),
  dimension.show.variance = F
);

## Plot a trajectory set
ena.plot.set(
  df.set.traj.lws,
  plot.mode="units",
  units = unique(df.set.traj.lws$get.data("centered")$ENA_UNIT)[1:10], #sample(df.set.lws$get.data("centered")$ENA_UNIT,1),
  unit.group = "Condition",
  unit.group.size = 2,
  unit.trajectory.by = c("ActivityNumber")
)

# ena.plot.set(
#   df.set.lws,
#   plot.mode="network",
#   network.one="brandon f.SecondGame"
# );
#
# ena.plot.set(
#   df.set.lws,
#   plot.mode="units",
#   unit.group = "Condition",
#   unit.group.size = 2
# )
