library(rPython)
library(data.table)
python.load( system.file("demo","backup","points-v3-1.py", package = "rENA") )

data = list(
  one = system.file("extdata", "bigdata", "anita.y2pre.post.aug.13ab.copy.1.csv", package="rENA"),
  two = system.file("extdata", "bigdata", "SDH_refined_codes.csv", package="rENA"),
  three = system.file("extdata", "bigdata","ls_all_runs_coded.csv", package="rENA"),
  four = system.file("extdata","rs.data.csv", package="rENA")
)
units = list(
  one = c("Participants", "Question"),
  two = c('School', 'speaker'),
  three = c("user_id","game"),
  four = c("UserName","Condition")
)
conversations = list(
  one = c("Participants", "Question"),
  two = c("School", "speaker", "rowID"),
  three = c('user_id', 'game', 'group_id', 'room_id'),
  four = c("GroupName","ActivityNumber")
)
codes = list(
  one = c("B1", "B2", "B3", "D15", "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8", "E9", "E10"),
  two = c("Education", "International.location", "School.location", "Home.location", "Prejudice.Discrimination", "Opportunity",  "social.status", "Class", "Race.Ethnicity", "Daily.Decisions", "Hard.work", "Upbringing"),
  three = c("s.urban.planning.tools", "k.urban.planning.tools", "k.complex.systems", "e.representing.stakeholders", "v.representing.stakeholders", "k.representing.stakeholders", "e.environmental.issues", "k.environmental.issues" ),
  #four = c("E.data","S.data","E.design","S.design","S.professional","E.client","V.client","E.consultant","V.consultant","S.collaboration","I.engineer","I.intern","K.actuator","K.rom","K.materials","K.power", "K.sensor", "K.attribute","K.data","K.design")
  four = c('Tradeoffs','Performance.Parameters','Constraints.and.Requests','Collaboration','Data')
)

if(!exists("accumulated", envir=.GlobalEnv)) {
  assign("accumulated", list(), envir=.GlobalEnv)
}

track.one = NULL;

reset <- function() {
  track.one <<- list(
    one = list(),
    two = list(),
    three = list()
  )
}


interpretive.correlation = function(x, t, w) {
  # :::::: parameter validation ::::::
  if (class(x) != "matrix" & class(x) != 'data.frame')
    x = matrix(x, ncol = 1, dimnames = list(names(x), "PC1"))

  MPS = function(xi){
    CC = which(upper.tri(diag(length(xi))),arr.ind=T)
    out = (xi[CC[,1]] + xi[CC[,2]])/2
    return(out)
  }
  N = nrow(x)
  K = nrow(t)
  M = min(c(ncol(x), ncol(t)))
  iK = which(upper.tri(diag(K)), arr.ind = T)

  mps = matrix(nrow = choose(N, 2), ncol = M)
  for (m in 1:M) mps[, m] = MPS(x[, m])

  dpps = matrix(nrow=choose(K, 2), ncol=M)
  for (m in 1:M) dpps[, m] = t[iK[, 1], m] - t[iK[, 2], m]

  centroids = matrix(nrow = K, ncol = M)
  for (m in 1:M)
    centroids[, m] = apply(w, 1, function(z) sum(z*mps[, m])/sum(z))

  dcen = matrix(nrow = choose(K, 2), ncol = M)
  for (m in 1:M) dcen[, m] = centroids[iK[, 1], m] - centroids[iK[, 2], m]

  icorr = sapply(1:M, function(m) cor(dpps[, m], dcen[, m]))

  return(icorr)
}

run <- function(sets = c("one","two","three","four"), force = F) {
  N = length(sets);
  results = data.table(
    "name"=character(N),
    "wes.1"=numeric(N),"wes.2"=numeric(N),
    # "wes.1.int"=numeric(N),"wes.2.int"=numeric(N),
    "jeff.1"=numeric(N),"jeff.2"=numeric(N),
    "cody.1"=numeric(N),"cody.2"=numeric(N),
    "cody.passes" = logical(N),
    "jeff.passes" = logical(N),
    "units"=character(N), "conversations"=character(N), "codes"=character(N)
  );

  accumulate <- function() {
    ena.accumulate.data(
      data[[wh]],
      units.by = units[[wh]],
      conversations.by = conversations[[wh]],
      code.names = codes[[wh]],
      window.size = 4, binary = T
    )
  }

  result.row = 1;
  global.accumulated = get("accumulated", envir=.GlobalEnv)
  for(wh in sets) {
    base.name = basename(data[[wh]])
    if( force == T || is.null( global.accumulated[[base.name]]  ) ) {
      print(paste("Accumulating: ", base.name))
      global.accumulated[[base.name]] <- accumulate();
      assign("accumulated", global.accumulated, envir=.GlobalEnv)
    }
    track.one[[wh]]$accumulated <<- global.accumulated[[base.name]];

    set = ena.make.set(track.one[[wh]]$accumulated, position.method = egr.positions, optim.method = do_optimization);

    track.one[[wh]]$base.set <<- set;
    track.one[[wh]]$positions <<- list()

    wes = list(
      "nodes" = set$nodes$positions$sclaed,
      "correlations" = as.numeric(set$nodes$positions$optim$Correlations[1,])
    )
    # browser()
    track.one[[wh]]$positions[["wes"]] <<- wes
    pyt = python.call("get_positions", make.adj.matrices(set$data$normed), set$data$centered$rotated);
    pyt$nodes = t(matrix(unlist(pyt$nodes), nrow=2)); # matrix(unlist(pyt$nodes), byrow=T, nrow=length(pyt$nodes))
    track.one[[wh]]$positions[["jeff"]] <<- pyt
    cpp = linderoth_pos_es(set$data$normed, set$data$centered$rotated)
    track.one[[wh]]$positions[["cody"]] <<- cpp
    results[result.row]$name <- base.name
    # wes.cor = interpretive.correlation(set$nodes$positions$scaled, set$data$centered$rotated, set$data$normed)
    results[result.row]$wes.1 <- wes$correlations[1]
    results[result.row]$wes.2 <- wes$correlations[2]
    # results[result.row]$wes.1.int <- wes.cor[1] #wes$correlations[1]
    # results[result.row]$wes.2.int <- wes.cor[2] #wes$correlations[2]
    results[result.row]$jeff.1 <- pyt$correlations[[1]][1]
    results[result.row]$jeff.2 <- pyt$correlations[[1]][2]
    results[result.row]$cody.1 <- cpp$correlations[1]
    results[result.row]$cody.2 <- cpp$correlations[2]
    results[result.row]$cody.passes <- all.equal(cpp$correlations, pyt$correlations[[1]], tolerance = 1.5e-3) == T
    results[result.row]$jeff.passes <- all.equal(pyt$correlations[[1]], wes$correlations, tolerance = 2e-1) == T
    results[result.row]$units <- paste(units[[wh]], collapse=",")
    results[result.row]$conversations <- paste(conversations[[wh]], collapse=",")
    results[result.row]$codes <- paste(codes[[wh]], collapse=",")
    result.row = result.row + 1;
  }

  results
}

results = run(force = T)
