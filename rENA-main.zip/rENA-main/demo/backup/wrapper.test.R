### Test Wrapper Function ###

rm(list=ls())


# With RSData #

data(RS.data)


codes = c('Data',
          'Technical.Constraints',
          'Performance.Parameters',
          'Client.and.Consultant.Requests',
          'Design.Reasoning',
          'Collaboration')

data = RS.data
units = c("UserName","Condition", "GroupName")
convo = c("Condition","GroupName")
meta = c("CONFIDENCE.Change","CONFIDENCE.Pre","CONFIDENCE.Post","C.Change")
window.type = "MovingStanzaWindow"
window.size = 10
group1 = "FirstGame"
group2 = "SecondGame"
groupVar = "Condition"

rs = ena(
  data = RS.data,
  codes = codes,
  units = units,
  conversation = convo,
  window.size.back = window.size,
  print.plots = F,
  groupVar = groupVar,
  groups = c("FirstGame", "SecondGame")
)



# With Navy Data #

data = read.csv("demo/backup/Wrapper_Function_Testing/TADMUSCoded.csv",stringsAsFactors = FALSE)

codes = c("SeekingInformation",
          "DetectIdentify",
          "TrackBehavior",
          "StatusUpdate",
          "AssessmentPrioritization",
          "DefensiveOrders",
          "DeterrentOrders",
          "Recommendation")

units = c("Team","Speaker")
convo = c("Team","Scenario")
meta = c("COND","MacroRole")
window.type = "MovingStanzaWindow"
window.size = 5
group1 = "Experimental"
group2 = "Control"
groupCol = "COND"

navy = ena_old(data = data,
                codes = codes,
                units = units,
                conversation = convo,
                metadata = meta,
                window = window.type,
                window.size.back = window.size,
                groupCol = groupCol,
                group1 = group1,
                group2 = group2)


############  Wrapper version 2

data(RS.data)


codes = c('Data',
          'Technical.Constraints',
          'Performance.Parameters',
          'Client.and.Consultant.Requests',
          'Design.Reasoning',
          'Collaboration')

data = RS.data
units = c("UserName","Condition", "GroupName")
convo = c("Condition","GroupName")
meta = c("CONFIDENCE.Change","CONFIDENCE.Pre","CONFIDENCE.Post","C.Change")
window.type = "MovingStanzaWindow"
window.size = 10
# group1 = "FirstGame"
# group2 = "SecondGame"
groupVar = "Condition"

rs = ena.set.creator(data = data,
                      codes = codes,
                      units = units,
                      conversation = convo,
                      window.size.back = window.size,
                      groupVar = "Condition",
                      groups = c("FirstGame","SecondGame"),
                      runTest = T,
                      testType = "parametric"

)



t = ena.plotter(set = rs,groupVar = "Condition",network = T,points = T,mean = T)

t$model$plots



### with TADMUS data

data = read.csv("demo/backup/Wrapper_Function_Testing/TADMUSCoded.csv",stringsAsFactors = FALSE)

codes = c("SeekingInformation",
          "DetectIdentify",
          "TrackBehavior",
          "StatusUpdate",
          "AssessmentPrioritization",
          "DefensiveOrders",
          "DeterrentOrders",
          "Recommendation")

units = c("Team","Speaker")
convo = c("Team","Scenario")
meta = c("COND","MacroRole")
window.type = "MovingStanzaWindow"
window.size = 5
groups = c("Experimental","Control")
groupVar = "COND"

navy = ena.set.creator(data = data,
                       codes = codes,
                       units = units,
                       conversation = convo,
                       metadata = meta,
                       window = window.type,
                       window.size.back = window.size,
                       groupVar = "MacroRole",
                       # groups = c("Support","Command","Other"),
                       runTest = T)

nt = ena.plotter(set = navy, groupVar = "MacroRole",groups = c("Support","Command","Other"), network = F,points = F,mean = T)

nt$model$plots


navy = ena(data = data,
           codes = codes,
           units = units,
           conversation = convo,
           metadata = meta,
           window = window.type,
           window.size.back = window.size,
           groupVar = "MacroRole",
           # groups = groups,
           runTest = T,
           points = F,
           network = T,
           mean = T,
           showPlots = T)


navy$model$plots
