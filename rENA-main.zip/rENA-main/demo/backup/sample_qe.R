;
library(data.table);

data(RS.data)
# codenames <- c("Data", "Technical.Constraints", "Performance.Parameters","Client.and.Consultant.Requests", "Design.Reasoning", "Collaboration")
# accum <- rENA:::ena.accumulate.data.file(
#       RS.data, units.by = c("UserName", "Condition"),
#       conversations.by = c("ActivityNumber", "GroupName"),
#       codes = codenames
#     )

#' @export
.DollarNames.qe.frame <- function(x, pattern = "") {
  # browser()
  # print("WHOA")
  1:10
}
#' @export
.DollarNames.qe.code <- function(x, pattern) {
  LETTERS
}
# "$.qe.frame" <- function(x, i) {
#   print(1:30);
#   3
# }
# "$.qe.code" <- function(x, i) {
#   print(1:10);
#   1
# }

as.qe.frame <- function(x) {
  if(!is(x, "qe.frame")) {
    x <- data.table::as.data.table(x);
    class(x) <- c("qe.frame", class(x));
  }
  return(x);
}
as_qe <- function(x, klass, as_factors = FALSE) {
  if(!as_factors && is.factor(x)) {
    x = as.character(x);
  }
  class(x) = c(klass, class(x));
  return(x);
}
as.qe.code <- function(x) {
  return(as_qe(x, "qe.code"));
}
as.qe.unit <- function(x) {
  return(as_qe(x, c("qe.unit", "qe.meta")));
}
as.qe.conversation <- function(x) {
  return(as_qe(x, c("qe.conversation", "qe.meta")))
}

#' Title
#'
#' @param data data.frame, data.table or
#' @param x vector of column names or indices
#'
#' @return
#' @export
#'
#' @examples
codes <- function(x, codes) {
  x <- as.qe.frame(x);

  for(col in codes) {
    data.table::set(x = x, j = col, value = as.qe.code(x[[col]]))
  }
  attr(x, "qe.codes") <- codes;
  invisible(x)
}

#' Title
#'
#' @param data data.frame, data.table or
#' @param x vector of column names or indices
#'
#' @return
#' @export
#'
#' @examples
units <- function(x, units) {
  x <- as.qe.frame(x);

  for(col in units) {
    data.table::set(x = x, j = col, value = as.qe.unit(x[[col]]))
  }
  attr(x, "qe.units") <- units;
  invisible(x)
}

#' Title
#'
#' @param data data.frame, data.table or
#' @param x vector of column names or indices
#'
#' @return
#' @export
#'
#' @examples
conversations <- function(x, convs) {
  x <- as.qe.frame(x);

  for(col in convs) {
    data.table::set(x = x, j = col, value = as.qe.conversation(x[[col]]))
  }
  attr(x, "qe.conversations") <- convs;
  invisible(x)
}
accumulate <- function(x, ...) {
  codes <- attr(x, "qe.codes");
  units <- attr(x, "qe.units");
  conversations <- attr(x, "qe.conversation");
  accum <- rENA:::ena.accumulate.data.file(x, units.by = units, codes = codes, conversations.by = conversations)
  x <- cbind(ENA_UNIT = accum$model$row.connection.counts$ENA_UNIT, x, accum$model$row.connection.counts[, rENA::find_code_cols(accum$model$row.connection.counts), with = F]);

  connection_cols <- which(rENA::find_code_cols(x = accum$connection.counts))
  connection_cols <- c(ENA_UNIT = which(colnames(accum$connection.counts) == "ENA_UNIT"), connection_cols)

  x <- x[accum$connection.counts[, ..connection_cols, with = F], , on = .(ENA_UNIT)]

  code_cols <- which(rENA::find_code_cols(x = x))
  for(y in seq(code_cols)) {
    i = y;
    if(y > length(code_cols) / 2)
      i = i - (length(code_cols) / 2);

    attr(x[[code_cols[y]]], "codes") <- as.character(accum$rotation$adjacency.key[[i]])
  }

  x <- as.qe.frame(x);
  invisible(x)
}
model <- function(x, ...) {
  codes <- attr(x, "qe.codes");
  units <- attr(x, "qe.units");
  conversations <- attr(x, "qe.conversation");
  accum <- rENA::ena(data = x, codes = codes, units = units, conversation = conversations, ...);

  x <- cbind(x, accum$model$row.connection.counts[, rENA::find_code_cols(accum$model$row.connection.counts), with = F]);
  invisible(x);
}

d <- RS.data |>
  codes(c("Data", "Technical.Constraints", "Performance.Parameters","Client.and.Consultant.Requests", "Design.Reasoning", "Collaboration")) |>
  units(c("UserName")) |>
  conversations(c("Condition", "GroupName")) |>
  accumulate()


# print(class(d))
# str(d)



