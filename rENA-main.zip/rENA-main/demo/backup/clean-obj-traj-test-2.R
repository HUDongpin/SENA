data(RS.data)

codeNames = c('Data','Technical.Constraints','Performance.Parameters',
              'Client.and.Consultant.Requests','Design.Reasoning','Collaboration');

accum = ena.accumulate.data(
  units = RS.data[,c("UserName","Condition")],
  conversation = RS.data[,c("GroupName","ActivityNumber")],
  metadata = RS.data[,c("CONFIDENCE.Change","CONFIDENCE.Pre","CONFIDENCE.Post","C.Change")],
  codes = RS.data[,codeNames],
  window.size.back = 4,
  model = "A"
);

set = ena.make.set(accum);

first.game.points = set$points$Condition$FirstGame
second.game.points = set$points$Condition$SecondGame

### get mean network plots
first.game.lineweights = set$line.weights$Condition$FirstGame
first.game.mean = colMeans(as.matrix(first.game.lineweights))

second.game.lineweights = set$line.weights$Condition$SecondGame
second.game.mean = colMeans(second.game.lineweights)

subtracted.network = first.game.mean - second.game.mean

# Plot dimension 1 against ActivityNumber metadata
points = as.matrix(set$points)
dim.by.activity = cbind(
  set$points$SVD1,
  set$trajectories$ActivityNumber # * .8/14-.4  #scale down to dimension 1
  # scales::rescale(x = as.numeric(set$trajectories$ActivityNumber), to = 0:1)
)

ena.plot(set) |> ena.plot.trajectory(
  points = dim.by.activity,
  names = unique(set$points$UserName),
  by = set$points$UserName
);
