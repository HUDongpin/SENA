# ::::::::::::::::::::::: #
# :::::: functions :::::: #
# ::::::::::::::::::::::: #
window.to.ord = function(g, u) {
  codes = colnames(u);
  g = colSums(g);

  out = matrix(nrow=0, ncol=2*length(codes));
  colnames(out) = LETTERS[1:ncol(out)];
  colnames(out)[1:length(codes)] = apply(rbind(codes,"s"),2,paste,collapse=".");
  colnames(out)[(length(codes)+1):ncol(out)] = apply(rbind(codes,"r"),2,paste,collapse=".");

  key = rbind(c(colnames(u),colnames(u)),
              c(rep("s",ncol(u)),rep("r",ncol(u))))

  # do u first
  if(sum(u)>1) {
    for(n in which(u==1)) {
      for(m in which(u==1)) {
        if(m!=n) {
          out = rbind(out, 0)
          out[nrow(out), key[1,]==codes[n]&key[2,]=="s"] = 1
          out[nrow(out), key[1,]==codes[m]&key[2,]=="r"] = 1
        }
      }
    }
  }

  for(n in which(u==1)) {
    for(m in which(g==1)) {
      out = rbind(out, 0)
      out[nrow(out), key[1,]==codes[n]&key[2,]=="s"] = 1
      out[nrow(out), key[1,]==codes[m]&key[2,]=="r"] = 1
    }
  }

  return(out);
}


# :::::::::::::::::::: #
# :::::: script :::::: #
# :::::::::::::::::::: #
df.file <- system.file("extdata", "rs.data.csv", package="rENA")
# df.file <- 'data/RSdata1.csv'
#outputPath = 'output/RSdata1.ordered.csv'
x = read.csv(df.file, stringsAsFactors = F)

codes = c("Tradeoffs",
          "Performance.Parameters",
          "Constraints.and.Requests",
          "Collaboration",
          "Data")

meta.names = c('UserName', 'Condition')
temporal.names = c('ActivityNumber')
all.meta.names = c(meta.names, temporal.names)

window.size = 4

# initialize new data for later accumulation in web tool
out = matrix(nrow=0, ncol=2*length(codes), dimnames=list(NULL, c(codes, codes)))
for(n in 1:length(codes)) {
  colnames(out)[n] = paste(c(colnames(out)[n],"s"),collapse='.');
}
for(n in (length(codes)+1):ncol(out)) {
  colnames(out)[n] = paste(c(colnames(out)[n],"r"),collapse='.')
}

out.meta = matrix(nrow=0, ncol=length(meta.names), dimnames=list(NULL, meta.names))
out.other = matrix(nrow=0,
                   ncol=length(setdiff(colnames(x),codes)),
                   dimnames=list(NULL, setdiff(colnames(x),codes)))

if (length(meta.names)>1) {
  m = apply(x[, meta.names], 1, paste, collapse='.')
} else {
  m = x[, meta.names]
}
if (length(temporal.names)>1) {
  e = apply(x[, temporal.names], 1, paste, collapse='.')
} else {
  e = x[, temporal.names]
}

# subset lines for unit
for(unit in unique(m)) {
  x1 = x[m == unit, ]
  m1 = m[m == unit]

  # subset lines for day
  for(tmprl in unique(e)) {
    x2 = x1[ e == tmprl, ]
    #m2 = m1[ e == tmprl, ]

    if(!nrow(x2)) next

    # pull window
    for(n in 1:nrow(x2)) {
      # current utterance
      u = x2[n, codes]

      # determine how many utterances to pull for (upper) window
      if(n == 1) g = matrix(0, nrow = 1, ncol = length(codes), dimnames = list(NULL, codes))
      if(n > 1 & n < window.size - 1) g = x2[1:(n-1), codes]
      if(n >= window.size)  g = x2[(n - window.size):(n - 1), codes]


      if(!any(is.na(u))) {
        new.lines = window.to.ord(g, u)
        out = rbind(out, new.lines)

        if(nrow(new.lines)>0) {
          for(i in 1:nrow(new.lines)) {
            out.meta = rbind(out.meta, x2[n, all.meta.names])
            # grab all other columns too
            other.col.names = setdiff(names(x), all.meta.names)
            other.col.names = setdiff(other.col.names, codes)
            out.other = rbind(out.other, x2[n, other.col.names])
          }
        }
      }
    }
  }
}

out = cbind(out.other,out)

# write.csv(out, outputPath, row.names=F)
#
#
# # :::::::::::::::::::::::: #
# # :::::: accumulate :::::: #
# # :::::::::::::::::::::::: #
# file = read.csv(outputPath)
# accum = ena.accumulate.data.file(
#   units = file[,c(“UserName”,”Condition”)],
#   conversation = file[,c("Condition","GroupName")],
#   codes = file[,codeNames],
#   window.size.back = 3
# );
