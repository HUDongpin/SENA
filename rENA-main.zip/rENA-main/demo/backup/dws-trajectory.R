
library(data.table)
data("RS.data")

# d = RS.data
# ## Animate function
# myAnimate <- function(
#   thesePoints,
#   scale = c(-101, 101),
#   frame = 1100,
#   transition = 1000,
#   easing = "circle-in-out"
# ) {
#   ax <- list(
#     range = scale,
#     title = "",
#     zeroline = FALSE,
#     showline = FALSE,
#     showticklabels = FALSE,
#     showgrid = FALSE
#   )
#
#   thisPlot <- thesePoints |>
#     plot_ly(x = ~x, y = ~y, z = ~z,
#       frame = ~frame,
#       type = 'scatter3d',
#       mode = 'markers',
#       marker = list(
#         size = ~size,
#         opacity = ~opacity,
#         color = ~color
#       )
#     ) |> layout(
#       xaxis = ax,
#       yaxis = ax,
#       showlegend = F
#     ) |> animation_opts(
#       frame = frame,
#       transition = transition,
#       easing = easing,
#       redraw = T
#     )
#
#   return(thisPlot)
# }


#d = data.table::data.table(RS.data, stringsAsFactors = F)
#d = d[order(d$ActivityNumber),]
#d$ActivityName = " "
# ActNames = c(
#   "01.Introduction and Workflow Tutorial with Entrance Interview",
#   "02.Staff Bio Page",
#   "03.Background Research on Exoskeletons",
#   "04.Graphing Power Source and Control Sensor Data",
#   "05.Team discussion of power source and control sensors",
#   "06.Summarize internal consultant requirements",
#   "07.Choose consultants to analyze",
#   "08.Individuals design 5 prototypes",
#   "09.Team designs batch using 1 actuator",
#   "10.Individual analysis of first batch",
#   "11.Team discussion of first batch results",
#   "12.New teams design second batch",
#   "13.Individual analysis of second batch",
#   "14.Team discussion of second batch results",
#   "15.Individual final design justification",
#   "16.Presentation Preparation",
#   "17.Presentations and peer assessment",
#   "18.Exit interview w team bonuses"
# )
# for (i in 1:length(unique(d$ActivityNumber))){
#   d$ActivityName[d$ActivityNumber == i] = ActNames[i]
# }


##set parameters

n = colnames(RS.data)
myGroups = "Condition"
myCodes = n[15:20]
myUnits = n[1:2]
myConversation = n[10:11]
myWindow = 4
thickness = 30

##Run endpoint model
modelType =  "EndPoint"
set_end = ena(
  model = modelType,
  showPlots = F,
  groupVar = myGroups,
  groups = as.character(unique(RS.data[,myGroups])[1:2]),
  data = RS.data,
  codes = myCodes,
  units = myUnits,
  conversation = myConversation,
  window.size.back = myWindow,
  include.plots = F
)

#set.plot = plot(set) |>
#  add_points(Condition$FirstGame) |>
#  add_points(Condition$SecondGame, colors = "red")

## Run trajectory model
modelType =  "AccumulatedTrajectory"

# thisSet = ena.accumulate.data(units = d[,myUnits], conversation = d[,myConversation], codes = d[,myCodes], model = modelType, window.size.back = myWindow)
# thisSet = ena.make.set(enadata = thisSet, dimensions = 2, rotation.set = endpointSet$rotation.set)

set_traj = ena(
  model = modelType,
  showPlots = F,
  groupVar = myGroups,
  groups = as.character(unique(RS.data[, myGroups])[1:2]),
  data = RS.data,
  codes = myCodes,
  units = myUnits,
  conversation = myConversation,
  window.size.back = myWindow,
  include.plots = F
)
point_plot = set_traj |> plot() |> add_points(Condition$FirstGame) |> add_points(Condition$SecondGame)


# subs = TRUE
# people <- set_traj$trajectories[subs, ]
# points <- set_traj$points[subs, ]
# steps <- c("ActivityNumber") #, "GroupName")
# userNames <- c("UserName", "Condition")
# rotationMatrix <- set_end$rotation.matrix

##Prep for Animation
# makeAnimationSet <- function (
#   units, idColumn, stepColumn, points, rotationMatrix
# ) {
#   unique_unit_values <- unique(units[, c(..idColumn, "ENA_UNIT")])
#   full_data <- cbind(units, as.matrix(points) %*% rotationMatrix)
#   full_data <- full_data[, unique(names(full_data)), with = FALSE]
#
#   all_steps_w_zero <- data.table(rbind(
#     rep(0, length(stepColumn)),
#     expand.grid(
#       sapply(stepColumn, function(x) sort(unique(units[[x]]))),
#       stringsAsFactors = F
#     )
#   ))
#   colnames(all_steps_w_zero) <- stepColumn
#   all_step_data <- CJ(all_steps_w_zero[[stepColumn]], unique_unit_values$ENA_UNIT)
#   colnames(all_step_data) <- c(stepColumn, "ENA_UNIT")
#   all_step_data[, colnames(rotationMatrix) := 0]
#   all_step_data[[stepColumn]] = as.ena.metadata(all_step_data[[stepColumn]])
#   all_step_data = merge(unique_unit_values, all_step_data, by = "ENA_UNIT")
#   setkey(all_step_data, "ENA_UNIT")
#
#   filled_data = all_step_data[ , {
#       by_names = names(.BY)
#       user_rows = sapply(1:length(by_names), function(n) {
#           full_data[[by_names[n]]] == .BY[n]
#       })
#       existing_row = which(rowSums(user_rows * 1) == 2)
#       if(length(existing_row) > 0) {
#         full_data[existing_row, colnames(rotationMatrix), with = FALSE]
#       } else {
#         prev_row = tail(full_data[ENA_UNIT == .BY$ENA_UNIT & ActivityNumber < .BY$ActivityNumber,], 1)
#         if(nrow(prev_row) == 0) {
#           data.table(matrix(rep(0, ncol(rotationMatrix)), nrow = 1, dimnames = list(NULL, colnames(rotationMatrix))))
#         } else {
#           prev_row[, colnames(rotationMatrix), with = FALSE]
#         }
#       }
#
#   },  by = c("ENA_UNIT", stepColumn)]
#   return(filled_data)
# }
# tPoints_new = makeAnimationSet(people, userNames, steps, points, as.matrix(rotationMatrix))


# trajectoryMovie = function(
#   data,
#   frame.order = c("default"),
#   size = 10,
#   opacity = 1,
#   scale = c(-101,101),
#   frame = 1100,
#   transition = 1000,
#   easing = "circle-in-out",
#   add.jitter = T
# ) {
#   dims = as.matrix(remove_meta_data(data)[, 1:2])
#   if(add.jitter) {
#     dims[, 1] = jitter(dims[, 1])
#     dims[, 2] = jitter(dims[, 2])
#   }
#
#   ax <- list(
#     range = scale,
#     title = "",
#     zeroline = TRUE,
#     showline = FALSE,
#     showticklabels = FALSE,
#     showgrid = FALSE
#   )
#
#   thisPlot <- data |>
#     plot_ly(
#       x = dims[,1], y = dims[,2],
#       text = ~ENA_UNIT,
#       frame = ~ActivityNumber,
#       type = 'scatter',
#       mode = 'markers',
#       marker = list(
#         size = size,
#         opacity = opacity,
#         hoverinfo = "text",
#         color = ~color
#       )
#     ) |>
#     layout(
#       xaxis = ax,
#       yaxis = ax,
#       showlegend = F
#     ) |>
#     animation_opts(
#       frame = frame,
#       transition = transition,
#       easing = easing,
#       redraw = T
#     )
#
#   return(thisPlot)
# }

# plotPoints = as.matrix( tPoints_new[,c("MR1", "SVD2")] )
# plotFrames = as.data.frame(tPoints_new[, c("ActivityNumber")])
# colorPoints = ifelse(grepl(x = tPoints_new$ENA_UNIT, pattern = "FirstGame"), "red", "blue")
# plotLabels = tPoints_new$ENA_UNIT
# tPoints_new$color = colorPoints
# setorder(tPoints_new, "ActivityNumber")
# mov = trajectoryMovie(
#   tPoints_new,
#   scale = c(min(plotPoints)*1.1, max(plotPoints)*1.1),
#   size = 10,
#   easing = "circle-in-out",
#   frame = 1100,
#   transition = 1000
# )
#
# print(mov)



