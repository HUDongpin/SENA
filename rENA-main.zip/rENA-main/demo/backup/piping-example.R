data(RS.data)

RS.data <- data.table::as.data.table(RS.data)

codes = c('Data','Technical.Constraints','Performance.Parameters','Client.and.Consultant.Requests','Design.Reasoning','Collaboration');
units = c("Condition", "UserName");
conversation = c("Condition","GroupName");

# Original
old_accum <- ena.accumulate.data(
  units = RS.data[,c("Condition","UserName")],
  conversation = RS.data[,c("Condition","GroupName")],
  metadata = RS.data[,c("CONFIDENCE.Change","CONFIDENCE.Pre","CONFIDENCE.Post","C.Change")],
  codes = RS.data[, ..codes],
  model = "EndPoint",
  window.size.back = 4
)
set_with_line_weights <- rENA::sphere_norm(old_accum)


old_model <- ena.make.set(old_accum)

# Just accumulation
accum1 <- RS.data |> accumulate(units, codes, conversation, default_window = 4); 

# Simple
enaset1 <- RS.data |>
  accumulate(units, codes, conversation, default_window = 4) |>
  model()

# Granular
enaset2 <- RS.data |>
  accumulate(units, codes, conversation, default_window = 4) |>
    sphere_norm() |>
    center() |>
    rotate() |>
    project() |>
    optimize()

# Just rotation
enaset3 <- RS.data |>
  accumulate(units, codes, conversation, default_window = 4) |>
  rotate()

# Same
all.equal(as.matrix(enaset1$points), as.matrix(enaset2$points))
all.equal(as.matrix(enaset1$rotation.matrix), as.matrix(enaset2$rotation.matrix))

# Not the same
all.equal(as.matrix(enaset1$points), as.matrix(enaset3$points))

rotate_params <- list();
enaset4 <- RS.data |>
  accumulate(units, codes, conversation) |>
  sphere_norm() |>
  center() |>
  rotate(ena.rotate.by.generalized) |>
  project() |>
  optimize()


# Same
all.equal(as.matrix(enaset3$points), as.matrix(enaset4$points))

enaset1 |> plot(title = "set 1") |> add_network() |> print()
enaset4 |> plot(title = "set 4") |> add_network() |> print()


codes = c('Data','Technical.Constraints','Performance.Parameters','Client.and.Consultant.Requests','Design.Reasoning','Collaboration');
units = c("Condition", "GameHalf", "UserName");
conversation = c("Condition","GroupName");

rotate_params_2 <- list(
  x_var = "Condition ~ V + GameHalf + Condition : GameHalf"
);
rotate_params_3 <- list(
  x_var = Condition ~ V + GameHalf + Condition : GameHalf
);

enaset5 <- RS.data |>
  accumulate(units, conversation, codes) |>
  model(
    rotate_params = rotate_params_2
  )
;

enaset6 <- RS.data |>
  accumulate(units, conversation, codes) |>
  sphere_norm() |>
  center() |>
  rotate(rotate_params_2$x_var)

enaset7 <- RS.data |>
  accumulate(units, conversation, codes) |>
  sphere_norm() |>
  center() |>
  rotate(formula(rotate_params_2$x_var))

enaset8 <- RS.data |>
  accumulate(units, conversation, codes) |>
  sphere_norm() |>
  center() |>
  rotate(rotate_params_3$x_var)

enaset9 <- RS.data |>
  accumulate(units, conversation, codes) |>
  sphere_norm() |>
  center() |>
  rotate(formula(rotate_params_3$x_var))


all.equal(as.matrix(enaset6$rotation.matrix), as.matrix(enaset8$rotation.matrix))
all.equal(as.matrix(enaset7$rotation.matrix), as.matrix(enaset8$rotation.matrix))
all.equal(as.matrix(enaset7$rotation.matrix), as.matrix(enaset9$rotation.matrix))


data(RS.data)

RS.data <- data.table::as.data.table(RS.data)

codes = c('Data','Technical.Constraints','Performance.Parameters','Client.and.Consultant.Requests','Design.Reasoning','Collaboration');
units = c("Condition", "UserName");
conversation = c("Condition","GroupName");

enaset4 <- RS.data |> 
  accumulate(units, codes, conversation, ordered = TRUE) |> 
  sphere_norm() |> 
  center() |> 
  rotate() |> 
  project() |>
  optimize()
