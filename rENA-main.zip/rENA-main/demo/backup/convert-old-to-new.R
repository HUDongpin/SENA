nd = data.table(rs.unnormed);
attr(nd, opts$UNIT_NAMES) = data.table(rs.win.4.retest$meta[,rs.win.4.retest$set.information$units])

test.set.2 = ENAset$new(list(
  data.units.summed = nd,
  data.units.summed.meta = nd,
  get = function(n) {
    if(n == "code.names") {
      rs.win.4.retest$set.information$codes
    } else if (n == "units.by" ) {
      rs.win.4.retest$set.information$units
    }
  }
))$process()
