library(microbenchmark)

data = list(
  small = system.file("extdata", "rs.data.csv", package="rENA"),
  medium = system.file("extdata", "sample-data","ls_all_runs_coded.csv", package="rENA"),
  large = system.file("extdata", "bigdata","dataset_for_ENA-FULL.csv", package="rENA")
)
units = list(
  small = c("UserName","Condition"),
  medium = c("user_id","game"),
  large = c('STUDENT_ID_WEEK')
)
conversations = list(
  small = c("ActivityNumber","GroupName"),
  medium = c("room_id","group_id"),
  large = c('row.id')
)
codes = list(
  small = c("E.data","S.data","E.design","S.design","S.professional","E.client","V.client","E.consultant","V.consultant","S.collaboration","I.engineer","I.intern","K.actuator","K.rom","K.materials","K.power"),
  medium = c('e.social.issues','k.social.issues','i.intern.identity','i.planner.identity','e.compromise','v.compromise','s.compromise','s.scientific.thinking','k.scientific.thinking','e.data','k.data','s.professionalism','s.zoning.codes','k.zoning.codes','s.urban.planning.tools','k.urban.planning.tools','k.complex.systems','e.representing.stakeholders','v.representing.stakeholders','k.representing.stakeholders','e.environmental.issues','k.environmental.issues'),
  large = c('FE_SCORE','T.ADM','T.ARC','T.ASP','T.CDL','T.COD','T.CST','T.DBOARD','T.DRM','T.HLP','T.ISA','T.NA','T.ORG','T.SDL','S.formative_assess','S.NA','S.readings','S.summative_assess')
)

times = NULL;
track.one = NULL;
reset <- function() {
  times <<- list(
    small = list(),
    medium = list(),
    large = list()
  )

  track.one <<- list(
    small = list(),
    medium = list(),
    large = list()
  )
}

run <- function(wh = c("small","medium","large"), times = 100) {
  wh = match.arg(wh);

  accumulate <- function() {
    ena.accumulate.data(
      data[[wh]],
      units.by = units[[wh]],
      conversations.by = conversations[[wh]],
      code.names = codes[[wh]]
    )
  }

  times[[wh]]$accumulation <<- microbenchmark(
    accumulate = accumulate(),
    times = times, unit = "s"
  );
  track.one[[wh]]$accumulated <<- accumulate();

  times[[wh]]$set <<- microbenchmark(
    make.set = ena.make.set(track.one[[wh]]$accumulated, position.method = lws.positions.es),
    times = times, unit = "s"
  );
  track.one[[wh]]$set <<- ena.make.set(track.one[[wh]]$accumulated, position.method = lws.positions.es);

  times[[wh]]$positions <<- microbenchmark(
    node.positions = lws.positions.es(track.one[[wh]]$set),
    times = times, unit = "s"
  );
}
