rm(list = ls())
library(rENA)


alldata.sa = read.csv("~/Downloads/codeddata_biounit_TV_SA_outcomescores.csv")
alldata.sa[34,c("Participant")] = alldata.sa[34,c("StudentID")]

codeNames <- c("bio.agents","bio.agent.actions","bio.systems","justifications","directional.change",
               "qualitative.amount","data","effects.change",
               "relationships","uncertainty","temporal.change",
               "variability","quantitative.amount","experimentation"     )

conversation = c("Curriculum","Step.No.","Question.No.");
meta = c("Score","HighLow");

accum = ena.accumulate.data(
  units = data.frame("Participant" = alldata.sa[, c("Participant")]),
  conversation = alldata.sa[, conversation],
  metadata = alldata.sa[, meta],
  codes = alldata.sa[, codeNames],
  model = "EndPoint",
  window.size.back = 2
)

# Set rotation by High == 1 and Low == 0
set = ena.make.set(
  enadata = accum,
  rotation.by = rENA:::ena.rotate.by.mean,
  rotation.params = list(accum$metadata$HighLow==1&!is.na(accum$metadata$HighLow), accum$metadata$HighLow==0&!is.na(accum$metadata$HighLow))
);

### Find rows that are High, along with points, weights, & mean
rows.high = accum$metadata$HighLow == 1 & !is.na(accum$metadata$HighLow)
points.high = set$points.rotated[rows.high,]
weights.high = set$line.weights[rows.high,]
mean.high = colMeans(weights.high)

### Find rows that are Low, along with points, weights, & mean
rows.low = accum$metadata$HighLow == 0 & !is.na(accum$metadata$HighLow)
points.low = set$points.rotated[rows.low,]
weights.low = set$line.weights[rows.low,]
mean.low = colMeans(weights.low)

### Calculate the subtracted network values
subtracted.network = mean.high - mean.low

### Plot, to use the `|>`, include .
### Otherwise, plot functions have to be called as follows,
### with the first parameter being the plot object that is returned
### from all plot the plot functions
####
### plot = ena.plot(set)
### plot = ena.plot.points(plot, points = points.high, colors = "blue")
### # ... other plot stuff ...
### print(plot)
ena.plot(set) |>
  ena.plot.points(points = points.high, colors = "blue") |>
  ena.plot.points(points = points.low, colors = "red") |>
  ena.plot.group(points.high, labels = "High", colors = "blue", confidence.interval = "box") |>
  ena.plot.group(points.low,  labels = "Low",  colors = "red",  confidence.interval = "box") |>
  ena.plot.network(network = subtracted.network, colors = c("blue","red"))


#### Trajectories
accum.traj = ena.accumulate.data(
  units = data.frame("Participant" = alldata.sa[, c("Participant")]),
  conversation = alldata.sa[, conversation],
  metadata = alldata.sa[, meta],
  codes = alldata.sa[, codeNames],
  model = "A",
  window.size.back = 2
)

units.and.meta = accum.traj$units[accum.traj$metadata, on=.(Participant)]

# Set rotation by High == 1 and Low == 0
set.traj = ena.make.set(
  enadata = accum.traj,
  rotation.by = rENA:::ena.rotate.by.mean,
  rotation.params = list(units.and.meta$HighLow==1&!is.na(units.and.meta$HighLow), units.and.meta$HighLow==0&!is.na(units.and.meta$HighLow))
)


### Find rows that are High, along with points, weights, & mean
rows.high = units.and.meta$HighLow == 1 & !is.na(units.and.meta$HighLow)
points.high = set.traj$points.rotated[rows.high,]
weights.high = set.traj$line.weights[rows.high,]
mean.high = colMeans(weights.high)

### Find rows that are Low, along with points, weights, & mean
rows.low = units.and.meta$HighLow == 0 & !is.na(units.and.meta$HighLow)
points.low = set.traj$points.rotated[rows.low,]
weights.low = set.traj$line.weights[rows.low,]
mean.low = colMeans(weights.low)

dim.by.question = cbind(
  set.traj$points.rotated[,1],
  units.and.meta$Step.No.  # *.8/14-.4  #scale down to dimension 1
)

ena.plot(set.traj) |>
  ena.plot.group(points.high, labels = "High", colors = "blue", confidence.interval = "box") |>
  ena.plot.group(points.low,  labels = "Low",  colors = "red",  confidence.interval = "box") |>
  ena.plot.trajectory(
    points = dim.by.question,
    names = unique(units.and.meta$Participant),
    by = units.and.meta$Participant
  )
