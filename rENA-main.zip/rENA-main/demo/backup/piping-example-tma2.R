library(qedata)

set_1 <- RS.data |>
  define(
    units = c("UserName", "Condition"),
    horizon = c("Condition", "GroupName", "ActivityNumber")
  ) |>
  accumulate(default_window = 4)

# FALSE
all.equal(set_2$connection.counts, set_3$connection.counts)
