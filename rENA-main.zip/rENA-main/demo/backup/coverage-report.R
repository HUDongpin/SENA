library(covr)


install.packages("rvest", repos = "https://cran.rstudio.com")
library(rvest)

args <- commandArgs(trailingOnly = TRUE)

perc <- sub(
    pattern = "rENA coverage - ",
    replacement = "",
    x = html_text(html_nodes(read_html(
            paste0(
                "inst/coverage/",
                ifelse(
                    length(args) > 0,
                    paste0(args[1], "/"),
                    ""
                ),
                "index.html"
            )
    ), "h2"))
)
numb <- round(as.numeric(sub(
    pattern = "%",
    replacement = "",
    x = perc
)))
print(perc)
print(numb)

ranges <- data.frame(
    scale = c(90, 70, 50),
    color = c("green", "orange", "red"),
    stringsAsFactors = F
)
print(ranges)
color <- ranges$color[head(which(ranges$scale <= numb), 1)]
print(color)
obj_name <- paste0(
                "coverage",
                ifelse(
                    length(args) > 0,
                    paste0("-", args[1]),
                    ""
                ),
                ".svg"
            )
print(obj_name)
aws.s3::put_object(
    file = httr::content(httr::GET(
        paste0("https://img.shields.io/badge/coverage-",
                    numb,
                    "%25-",
                    color,
                    ".svg")
    )),
    object = obj_name,
    bucket = "rena.qe-libs.org",
    acl = "public-read",
    serialize = TRUE,
    headers = list("Content-Type" = "image/svg+xml")
)
