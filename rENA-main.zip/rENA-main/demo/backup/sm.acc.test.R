devtools::load_all()

#sm.file = system.file("inst", "extdata", "rs.data.accum.test.csv", package = "rENA");
sm.file = system.file("inst", "extdata", "rs.data.csv", package = "rENA");

sm.acc = ena.accumulate.data(
  sm.file,
  units.by = c("UserName", "Condition"),
  conversations.by = c("GroupName", "GameDay"),
  #code.names = c("A", "B", "C", "D", "E"),
  code.names = c("E.data","S.data","E.design","S.design","S.professional","E.client","V.client","E.consultant","V.consultant","S.collaboration","I.engineer","I.intern","K.actuator","K.rom","K.materials","K.power", "K.sensor", "K.attribute","K.data","K.design"),
  window.size = 3,
  binary = T
)

namedData = data.table::copy(sm.acc$data.units.accumulated);
namedRows = attr(sm.acc$data.units.summed, "adjacency.matrix");
colnames(namedData)[grep("adjacency.code",colnames(namedData))] = apply(namedRows, 2, function(x) paste(x[1], x[2], sep="."))

write.csv(x = namedData, file = "~/Desktop/namedData.csv")


sm.set2= ena.make.set(sm.acc, position.method = egr.positions)
