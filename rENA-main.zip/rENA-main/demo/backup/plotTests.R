
plot(x=enaset$nodes$positions$scaled[,1]$scaled, y=enaset$nodes$positions$scaled[,2]$scaled, col = 0)
text(x=enaset$nodes$positions$scaled[,1]$scaled, y=enaset$nodes$positions$scaled[,2]$scaled, labels = c(1:16))
