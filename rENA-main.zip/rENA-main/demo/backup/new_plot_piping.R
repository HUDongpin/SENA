units = c("UserName", "Condition")
conversation = c("ActivityNumber", "GroupName")
codes = c("Data", "Technical.Constraints", "Performance.Parameters",
            "Client.and.Consultant.Requests", "Design.Reasoning",
            "Collaboration")

set_end = RS.data |>
  ena(
    units = units,
    conversation = conversation,
    codes = codes,
    window.size.back = 4
  )

set_inf = RS.data |>
  ena(
    units = units,
    conversation = conversation,
    codes = codes,
    window.size.back = Inf
  )

set_inf |>
  project_in(set_end) |>
  plot(title = "Projected") |>
  add_nodes() |>
  plot(title = "Regular") |>
  add_nodes() |> show()

set_traj <- set_end |> as_trajectory(by = "ActivityNumber")

set_inf |> plot() |>
    add_nodes() |>
    add_points(Condition)

set_end |> plot() |>
  add_group(Condition$FirstGame) |>
  add_group(Condition$SecondGame) |>
  means_rotate() |>
  add_group(Condition$FirstGame) |>
  add_group(Condition$SecondGame) |>
  show()

set_end |> plot() |>
  add_points(Condition$FirstGame, mean = T) |>
  add_points(Condition$SecondGame, mean = T) |>
  means_rotate() |>
  add_points(Condition$FirstGame, mean = T) |>
  add_points(Condition$SecondGame, mean = T) |>
  show()
