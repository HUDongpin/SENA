import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { accumulateData, refWindowMatrix, rowsToCoOccurrences, sphereNorm } from '../src/index.js';
import type { Row } from '../src/index.js';

const fixturePath = join(process.cwd(), 'fixtures/goldens/toy-endpoint.generated.json');

if (!existsSync(fixturePath)) {
  describe.skip('R golden parity', () => {
    it('requires fixtures/goldens/toy-endpoint.generated.json from npm run goldens:r', () => undefined);
  });
} else {
  describe('R golden parity', () => {
    const fixture = JSON.parse(readFileSync(fixturePath, 'utf8'));
    const rows = fixture.input as Row[];
    const codes = ['A', 'B', 'C'];

    it('matches low-level co-occurrence fixtures', () => {
      const matrix = rows.map((row) => codes.map((code) => Number(row[code])));
      expect(rowsToCoOccurrences(matrix, true)).toEqual(fixture.low_level.rows_to_co_occurrences_binary);
      expect(rowsToCoOccurrences(matrix, false)).toEqual(fixture.low_level.rows_to_co_occurrences_weighted);
      expect(refWindowMatrix(matrix, 2, 0, true)).toEqual(fixture.low_level.ref_window_back_2);
      expect(sphereNorm([[3, 4], [0, 0]])).toEqual(fixture.low_level.sphere_norm);
    });

    it('matches endpoint accumulation fixture', () => {
      const data = accumulateData({
        rows,
        units: ['unit'],
        conversation: ['conv'],
        codes,
        windowSizeBack: 2
      });
      expect(data.connectionCounts).toEqual(fixture.accumulate.connection_counts);
    });
  });
}
