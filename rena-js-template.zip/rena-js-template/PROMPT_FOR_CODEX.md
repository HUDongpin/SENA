# Prompt for Codex

You are working in a TypeScript repository that ports the R package **rENA** (Epistemic Network Analysis) to JavaScript/TypeScript for browser and Node use. The goal is to replace the slow/non-scalable R-based ENA workflow with a fast, testable, website-friendly implementation.

The original uploaded source is available at `reference/rENA-main`. The current scaffold already contains a strict TypeScript package, starter computational modules, tests, docs, and a minimal high-level API.

## Primary objective

Finish the rENA-to-TypeScript port with numerical parity against the R package for the supported API, while keeping the runtime free of R and suitable for web deployment.

## Non-negotiable constraints

- Do **not** require R, Rserve, OpenCPU, or a server-side R process at runtime.
- Use R only to generate golden fixtures for tests.
- Preserve the observable behavior of rENA unless an intentional compatibility break is documented.
- Keep the core computational package browser-safe and framework-agnostic.
- Keep plotting separate from computation; expose plain data structures that web UIs can render.
- Maintain GPL-3 compatibility unless the project owner changes licensing.
- Add tests before or with every algorithmic change.
- Run `npm run typecheck`, `npm test`, and `npm run build` before declaring work complete.

## Reference files to inspect first

Start with these files in `reference/rENA-main`:

1. `src/ena.cpp` — fast Rcpp functions: `combn_c2`, `rows_to_co_occurrences`, `ref_window_df`, `ref_window_lag`, `fun_sphere_norm`, `fun_skip_sphere_norm`, `center_data_c`, `triIndices`, `lws_lsq_positions`, directed node positions, and correlations.
2. `R/accumulate.data.R` — exact accumulation behavior for endpoint and trajectory models.
3. `R/ENAdata.R` — data-object processing, metadata handling, `ENA_UNIT`, masks, and raw/accumulated adjacency vectors.
4. `R/ena.accumulate.data.R` — public accumulation wrapper and argument normalization.
5. `R/ena.make.set.R` — line weights, centering, rotation, points, node positions, centroids, variance.
6. `R/ena.svd.R` — default rotation using `prcomp(..., center = FALSE, scale = FALSE)`.
7. `R/ena.rotate.by.mean.R`, `R/ena.rotate.by.generalized.R`, `R/ena.rotate.by.regression*.R`, `R/ena.rotation.h.R` — non-default rotations.
8. `R/ena.set.R`, `R/utils*.R`, `R/qedata_*.R` — object shape, helper classes, and column classification.
9. `tests/testthat/*.R` — expected behavior and edge cases.

## Work plan

### Phase 1 — Parity harness

1. Run the existing TypeScript tests.
2. Run or repair `scripts/generate-r-goldens.R` so it creates JSON fixtures from the R implementation.
3. Add golden tests comparing TypeScript outputs against R outputs for:
   - `rows_to_co_occurrences`;
   - `ref_window_df` for window back/forward combinations, including `Inf`;
   - endpoint accumulation;
   - `Conversation` window accumulation;
   - `AccumulatedTrajectory` and `SeparateTrajectory`;
   - `fun_sphere_norm` and `fun_skip_sphere_norm`;
   - `ena.make.set` default SVD rotation, points, line weights, nodes, centroids, and variance.

### Phase 2 — Complete accumulation

Complete `src/accumulate.ts` against `R/accumulate.data.R` and `R/ENAdata.R`.

Pay special attention to:

- exact upper-triangle co-occurrence order;
- binary versus weighted behavior;
- `weight.by` semantics;
- mask application using `upper.tri(mask)` order;
- conversation grouping;
- `window = Conversation` semantics;
- `window.size.back`, `window.size.forward`, `Inf`, and zero-window behavior;
- metadata inclusion rules;
- trajectory models and trajectory step labels;
- row-level connection counts versus unit-level connection counts.

### Phase 3 — Complete model generation

Complete `src/model.ts` and `src/rotation/*` against `R/ena.make.set.R`, `R/ena.svd.R`, and `src/ena.cpp`.

Required behavior:

- normalize connection counts into line weights using rENA-compatible row-wise L2 normalization;
- center only non-zero rows when `center.align.to.origin = TRUE`;
- implement projection into an existing rotation set;
- implement default SVD rotation with R-compatible orientation/sign handling where possible;
- implement least-squares node positions and centroids;
- compute variance like rENA;
- preserve object fields expected by downstream plotting and analysis code.

### Phase 4 — Rotations and statistics

Implement these modules with parity tests:

- means rotation;
- generalized means rotation;
- regression rotations;
- correlations with confidence intervals;
- Cohen’s d;
- project-in behavior;
- group summaries and statistical test outputs where practical.

### Phase 5 — Web-ready API and performance

After parity tests are stable:

- add typed-array optimized paths for large datasets;
- keep a simple row-object API for usability;
- move heavy computation into `src/browser/worker.ts` or worker-friendly functions;
- benchmark large synthetic datasets;
- add streaming/chunked accumulation if needed;
- expose JSON-serializable outputs for React/Vue/Svelte/D3/Plotly consumers.

## Acceptance criteria

A task is complete only when:

- TypeScript tests pass;
- golden parity tests pass or documented tolerances explain unavoidable numerical differences;
- all public APIs are typed;
- browser builds do not include R/runtime server dependencies;
- docs list supported and unsupported rENA features;
- performance-critical paths have tests and at least basic benchmarks.

## First action

Inspect `reference/rENA-main/src/ena.cpp`, `reference/rENA-main/R/accumulate.data.R`, and `reference/rENA-main/R/ena.make.set.R`; then run the existing TypeScript typecheck/tests. Start by making the parity harness reliable before expanding the API.
