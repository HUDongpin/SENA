# Codex instructions for this repository

## Mission

Port rENA from R/Rcpp to TypeScript for scalable web and Node use. The reference implementation is in `reference/rENA-main`. Do not guess behavior from ENA theory alone; inspect the R/Rcpp source and preserve observable behavior unless a deliberate breaking change is documented.

## Commands

Run these before proposing completion:

```bash
npm run typecheck
npm test
npm run build
```

When R is available, also run:

```bash
npm run goldens:r
npm run goldens:compare
```

## Development rules

1. Prefer correctness and parity before optimization.
2. Add or update tests for every algorithmic change.
3. Preserve rENA upper-triangle ordering: `A & B`, `A & C`, `B & C`, etc.
4. Preserve `ENA_UNIT` construction with `::` unless a compatibility option says otherwise.
5. Keep computational code framework-agnostic and browser-safe. Do not add server-only runtime dependencies to `src/`.
6. Avoid `any`; use explicit types in `src/types.ts`.
7. Document every parity gap in `docs/PARITY.md`.
8. Keep plotting separate from computation.
9. Do not require R at runtime. R is allowed only for generating test fixtures.
10. Treat the port as GPL-3-compatible unless licensing is changed by the project owner.

## Current implementation map

- `src/core/matrix.ts`: starter port of `src/ena.cpp` utilities.
- `src/accumulate.ts`: starter port of `R/ENAdata.R` + `R/accumulate.data.R` + `R/ena.accumulate.data.R`.
- `src/model.ts`: starter port of `R/ena.make.set.R`.
- `src/rotation/svd.ts`: starter SVD/PCA rotation equivalent to `R/ena.svd.R` using a dependency-free Jacobi eigensolver.
- `src/rotation/nodePositions.ts`: starter port of `lws_lsq_positions` / `lws.positions.sq` behavior.
- `src/plot/`: data adapters only; rendering belongs in downstream apps or optional adapters.
