import type { ENAData, ENASet, MakeSetOptions, Matrix, Row, RotationSet } from './types.js';
import { centerData, meanColumns, multiplyMatrices, sphereNorm, varianceColumns } from './core/matrix.js';
import { svdRotation } from './rotation/svd.js';
import { centroidsAsRows, lwsLeastSquaresPositions, nodesAsRows } from './rotation/nodePositions.js';

function nonCodePart(row: Row, codeColumns: string[]): Row {
  const codeSet = new Set(codeColumns);
  return Object.fromEntries(Object.entries(row).filter(([key]) => !codeSet.has(key))) as Row;
}

function rowsFromMatrix(baseRows: Row[], codeColumns: string[], columns: string[], matrix: Matrix): Row[] {
  return baseRows.map((row, rowIndex) => ({
    ...nonCodePart(row, codeColumns),
    ...Object.fromEntries(columns.map((column, columnIndex) => [column, matrix[rowIndex]?.[columnIndex] ?? 0]))
  }));
}

function selectMatrixColumns(matrix: Matrix, count: number): Matrix {
  return matrix.map((row) => row.slice(0, count));
}

function selectRotationColumns(rotationMatrix: Matrix, count: number): Matrix {
  return rotationMatrix.map((row) => row.slice(0, count));
}

function rowHasSignal(row: number[]): boolean {
  return row.reduce((sum, value) => sum + value, 0) !== 0;
}

function centerForProjection(lineWeights: Matrix, centerAlignToOrigin: boolean): { pointsForProjection: Matrix; centerVector: number[] } {
  if (!centerAlignToOrigin) {
    const centerVector = meanColumns(lineWeights);
    return { pointsForProjection: centerData(lineWeights, centerVector), centerVector };
  }

  const nonZeroRows = lineWeights.filter(rowHasSignal);
  if (nonZeroRows.length === 0) {
    throw new Error('There were no co-occurrences of codes for any of the units within the model as defined.');
  }
  const centerVector = meanColumns(nonZeroRows);
  return {
    centerVector,
    pointsForProjection: lineWeights.map((row) => (rowHasSignal(row) ? row.map((value, index) => value - (centerVector[index] ?? 0)) : row.map(() => 0)))
  };
}

export function makeSet(enadata: ENAData, options: MakeSetOptions = {}): ENASet {
  const dimensions = options.dimensions ?? 2;
  const centerAlignToOrigin = options.centerAlignToOrigin ?? true;
  const lineWeightsMatrix = sphereNorm(enadata.connectionMatrix);
  const { pointsForProjection, centerVector } = centerForProjection(lineWeightsMatrix, centerAlignToOrigin);
  const svd = svdRotation(pointsForProjection);
  const dimCount = Math.min(dimensions, svd.rotationColumns.length);
  const dimensionNames = svd.rotationColumns.slice(0, dimCount);
  const selectedRotation = selectRotationColumns(svd.rotationMatrix, dimCount);
  const pointsMatrix = multiplyMatrices(pointsForProjection, selectedRotation);
  const nodePositionResult = lwsLeastSquaresPositions(lineWeightsMatrix, pointsMatrix, enadata.codes.length);
  const variances = varianceColumns(pointsMatrix);
  const varianceTotal = variances.reduce((sum, value) => sum + value, 0);
  const variance = Object.fromEntries(dimensionNames.map((name, index) => [name, varianceTotal === 0 ? 0 : (variances[index] ?? 0) / varianceTotal]));

  const rotation: RotationSet = {
    codes: enadata.codes,
    adjacencyKey: enadata.adjacencyKey,
    rotationMatrix: selectedRotation,
    rotationColumns: dimensionNames,
    eigenvalues: svd.eigenvalues.slice(0, dimCount),
    centerVector,
    nodes: nodesAsRows(enadata.codes, nodePositionResult.nodes, dimensionNames)
  };

  return {
    ...enadata,
    lineWeights: rowsFromMatrix(enadata.connectionCounts, enadata.codeColumns, enadata.codeColumns, lineWeightsMatrix),
    pointsForProjection: rowsFromMatrix(enadata.connectionCounts, enadata.codeColumns, enadata.codeColumns, pointsForProjection),
    points: rowsFromMatrix(enadata.connectionCounts, enadata.codeColumns, dimensionNames, pointsMatrix),
    rotation,
    variance,
    centroids: centroidsAsRows(enadata.unitLabels, nodePositionResult.centroids, dimensionNames)
  };
}
