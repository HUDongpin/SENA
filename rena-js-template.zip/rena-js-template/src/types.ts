export type Scalar = string | number | boolean | null;
export type Row = Record<string, Scalar>;
export type Matrix = number[][];

export type ModelType = 'EndPoint' | 'AccumulatedTrajectory' | 'SeparateTrajectory';
export type WindowType = 'MovingStanzaWindow' | 'Conversation';
export type WeightBy = 'binary' | 'sum' | ((values: number[]) => number);

export interface AccumulateOptions {
  rows: Row[];
  units: string[];
  conversation: string[];
  codes: string[];
  metadata?: string[];
  model?: ModelType;
  weightBy?: WeightBy;
  window?: WindowType;
  windowSizeBack?: number;
  windowSizeForward?: number;
  mask?: Matrix;
  includeMeta?: boolean;
}

export interface AdjacencyKeyEntry {
  source: string;
  target: string;
  name: string;
  sourceIndex: number;
  targetIndex: number;
}

export interface ENAData {
  modelType: ModelType;
  codes: string[];
  units: string[];
  conversation: string[];
  codeColumns: string[];
  adjacencyKey: AdjacencyKeyEntry[];
  rawRows: Row[];
  rowConnectionCounts: Row[];
  connectionCounts: Row[];
  connectionMatrix: Matrix;
  metaData: Row[];
  unitLabels: string[];
  trajectories?: Row[];
  functionParams: Required<Pick<AccumulateOptions, 'model' | 'weightBy' | 'window' | 'includeMeta'>> & {
    windowSizeBack: number;
    windowSizeForward: number;
  };
}

export interface RotationSet {
  codes: string[];
  adjacencyKey: AdjacencyKeyEntry[];
  rotationMatrix: Matrix;
  rotationColumns: string[];
  eigenvalues: number[];
  centerVector: number[];
  nodes?: Row[];
}

export interface ENASet extends ENAData {
  lineWeights: Row[];
  pointsForProjection: Row[];
  points: Row[];
  rotation: RotationSet;
  variance: Record<string, number>;
  centroids?: Row[];
}

export interface MakeSetOptions {
  dimensions?: number;
  centerAlignToOrigin?: boolean;
}
