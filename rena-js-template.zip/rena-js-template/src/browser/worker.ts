import { ena } from '../ena.js';
import type { ENAOptions } from '../ena.js';

export interface ENAWorkerRequest {
  id: string;
  options: ENAOptions;
}

export interface ENAWorkerResponse {
  id: string;
  ok: boolean;
  result?: unknown;
  error?: string;
}

self.addEventListener('message', (event: MessageEvent<ENAWorkerRequest>) => {
  const { id, options } = event.data;
  try {
    const result = ena(options);
    const response: ENAWorkerResponse = { id, ok: true, result };
    self.postMessage(response);
  } catch (error) {
    const response: ENAWorkerResponse = { id, ok: false, error: error instanceof Error ? error.message : String(error) };
    self.postMessage(response);
  }
});
