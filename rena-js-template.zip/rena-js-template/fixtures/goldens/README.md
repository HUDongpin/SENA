# Golden fixtures

Golden fixtures should be generated from the original R implementation and committed as JSON when stable.

Run:

```bash
npm run goldens:r
```

This calls `scripts/generate-r-goldens.R` with `reference/rENA-main` as the default source directory and writes JSON files here.
