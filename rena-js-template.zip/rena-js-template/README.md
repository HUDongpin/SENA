# rENA → JavaScript/TypeScript project template

This repository is a Codex-ready scaffold for rewriting the R package **rENA** into a browser- and Node-compatible TypeScript library.

The template already includes:

- a strict TypeScript package structure;
- starter ports of the performance-critical co-occurrence/windowing utilities from `src/ena.cpp`;
- a first-pass `accumulateData()`, `makeSet()`, and `ena()` API;
- parity-oriented tests for upper-triangle ordering, moving stanza windows, accumulation, line weights, points, and node positions;
- a Codex prompt in [`PROMPT_FOR_CODEX.md`](./PROMPT_FOR_CODEX.md);
- Codex/agent operating rules in [`AGENTS.md`](./AGENTS.md);
- a trimmed copy of the uploaded rENA source under [`reference/rENA-main`](./reference/rENA-main), excluding large demo backups.

## Status

This is a **template and starting implementation**, not a complete rENA port yet. The core low-level utilities and a minimal end-to-end pipeline are in place so Codex can continue from a concrete baseline instead of starting from an empty repository.

The highest-priority next step is numerical parity against the R implementation using golden fixtures generated from the original package.

## Install and run

```bash
npm install
npm run typecheck
npm test
npm run build
```

Generate R golden fixtures when R and the rENA dependencies are available:

```bash
npm run goldens:r
npm run goldens:compare
```

## Example

```ts
import { ena } from 'rena-js-template';

const set = ena({
  rows: [
    { unit: 'u1', conv: 'c1', A: 1, B: 0, C: 0 },
    { unit: 'u1', conv: 'c1', A: 0, B: 1, C: 0 },
    { unit: 'u2', conv: 'c1', A: 1, B: 1, C: 0 }
  ],
  units: ['unit'],
  conversation: ['conv'],
  codes: ['A', 'B', 'C'],
  windowSizeBack: 2,
  dimensions: 2
});

console.log(set.connectionCounts);
console.log(set.points);
console.log(set.rotation.nodes);
```

## Suggested API direction

Keep the computational core independent from rendering:

- `accumulateData(options)` converts coded rows into connection counts.
- `makeSet(enadata, options)` normalizes, centers, rotates, and projects.
- `ena(options)` is the high-level wrapper.
- plotting should consume plain graph/point data and live in separate adapters.
- browser work should run heavy computation in `src/browser/worker.ts` or future typed-array/WebAssembly backends.

## License note

The uploaded rENA package is GPL-3. This port template is marked `GPL-3.0-only`. A faithful line-by-line or algorithmic derivative of rENA should remain GPL-compatible unless you obtain different licensing from the original copyright holders.
