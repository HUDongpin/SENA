#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
source_dir <- ifelse(length(args) >= 1, args[[1]], "reference/rENA-main")
out_dir <- ifelse(length(args) >= 2, args[[2]], "fixtures/goldens")

dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package 'jsonlite' is required to write golden fixtures.")
}

loaded <- FALSE
if (dir.exists(source_dir) && requireNamespace("devtools", quietly = TRUE)) {
  message("Loading local rENA source with devtools::load_all: ", source_dir)
  devtools::load_all(source_dir, quiet = TRUE)
  loaded <- TRUE
}

if (!loaded) {
  message("Loading installed rENA package")
  suppressPackageStartupMessages(library(rENA))
}

plain_df <- function(x) {
  out <- as.data.frame(x, stringsAsFactors = FALSE)
  rownames(out) <- NULL
  out
}

codes <- c("A", "B", "C")
toy <- data.frame(
  unit = c("u1", "u1", "u1", "u2"),
  conv = c("c1", "c1", "c1", "c1"),
  A = c(1, 0, 0, 1),
  B = c(0, 1, 0, 1),
  C = c(0, 0, 1, 0),
  stringsAsFactors = FALSE
)

accum <- ena.accumulate.data(
  units = toy[, c("unit"), drop = FALSE],
  conversation = toy[, c("conv"), drop = FALSE],
  codes = toy[, codes, drop = FALSE],
  window.size.back = 2,
  as.list = TRUE
)

set <- ena.make.set(accum, dimensions = 2)

payload <- list(
  input = plain_df(toy),
  low_level = list(
    rows_to_co_occurrences_binary = unname(as.matrix(rows_to_co_occurrences(toy[, codes], binary = TRUE))),
    rows_to_co_occurrences_weighted = unname(as.matrix(rows_to_co_occurrences(toy[, codes], binary = FALSE))),
    ref_window_back_2 = unname(as.matrix(ref_window_df(toy[, codes], windowSize = 2, windowForward = 0, binary = TRUE))),
    sphere_norm = unname(as.matrix(fun_sphere_norm(data.frame(x = c(3, 0), y = c(4, 0)))))
  ),
  accumulate = list(
    connection_counts = plain_df(accum$connection.counts),
    row_connection_counts = plain_df(accum$model$row.connection.counts),
    unit_labels = accum$model$unit.labels
  ),
  model = list(
    line_weights = plain_df(set$line.weights),
    points_for_projection = plain_df(set$model$points.for.projection),
    points = plain_df(set$points),
    rotation_matrix = plain_df(set$rotation$rotation.matrix),
    nodes = plain_df(set$rotation$nodes),
    centroids = plain_df(set$model$centroids),
    variance = set$model$variance
  )
)

jsonlite::write_json(
  payload,
  file.path(out_dir, "toy-endpoint.generated.json"),
  pretty = TRUE,
  auto_unbox = TRUE,
  digits = 15,
  null = "null"
)

message("Wrote ", file.path(out_dir, "toy-endpoint.generated.json"))
