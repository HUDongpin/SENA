# rENA porting map

| rENA source | TypeScript target | Notes |
| --- | --- | --- |
| `src/ena.cpp::combn_c2` | `src/core/matrix.ts::combnC2` | Preserve 0-based ordering used internally by C++ output. |
| `src/ena.cpp::vector_to_ut` | `src/core/matrix.ts::vectorToUpperTriangle` | Defines co-occurrence order. |
| `src/ena.cpp::svector_to_ut` | `src/core/matrix.ts::stringVectorToUpperTriangle` | Produces names like `A & B`. |
| `src/ena.cpp::rows_to_co_occurrences` | `src/core/matrix.ts::rowsToCoOccurrences` | Binary and weighted modes. |
| `src/ena.cpp::ref_window_df` | `src/core/matrix.ts::refWindowMatrix` | Needs extensive golden tests for back/forward/Inf behavior. |
| `src/ena.cpp::ref_window_lag` | `src/core/matrix.ts::refWindowLag` | Used for accumulated trajectories. |
| `src/ena.cpp::fun_sphere_norm` | `src/core/matrix.ts::sphereNorm` | Row-wise L2 normalization. |
| `src/ena.cpp::fun_skip_sphere_norm` | `src/core/matrix.ts::skipSphereNorm` | Divide by largest row norm. |
| `src/ena.cpp::center_data_c` | `src/core/matrix.ts::centerData` | Column-centering. |
| `src/ena.cpp::triIndices` | `src/core/matrix.ts::triIndices` | Used to build adjacency key. |
| `src/ena.cpp::lws_lsq_positions` | `src/rotation/nodePositions.ts::lwsLeastSquaresPositions` | Least-squares node positions. |
| `R/accumulate.data.R` | `src/accumulate.ts` | Main accumulation behavior. |
| `R/ENAdata.R` | `src/accumulate.ts` + `src/types.ts` | Object shape and metadata behavior. |
| `R/ena.make.set.R` | `src/model.ts` | Model generation. |
| `R/ena.svd.R` | `src/rotation/svd.ts` | Default rotation. |
| `R/ena.rotate.by.mean.R` | `src/rotation/mean.ts` | TODO. |
| `R/ena.rotate.by.generalized.R` | `src/rotation/generalized.ts` | TODO. |
| `R/ena.plot*.R` | `src/plot/` | Prefer data adapters, not mandatory rendering. |
