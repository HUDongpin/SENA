# Architecture

The port is organized into layers so website applications can use the computational core without pulling in plotting or server-only dependencies.

## Layers

1. `src/core/` — matrix, table, normalization, windowing, and linear algebra utilities.
2. `src/accumulate.ts` — converts coded row data into row-level and unit-level ENA connection counts.
3. `src/model.ts` — creates line weights, centered projection data, rotations, points, nodes, centroids, and variance.
4. `src/rotation/` — SVD/PCA, node position solvers, and future means/regression/generalized rotations.
5. `src/plot/` — data adapters for network/point rendering. It should not depend on a specific UI framework.
6. `src/browser/` — worker-friendly wrappers for heavy computation.

## Data flow

```text
coded rows
  -> accumulateData()
  -> ENAData: rowConnectionCounts + connectionCounts + metadata
  -> makeSet()
  -> ENASet: lineWeights + points + rotation + nodes + centroids
  -> plot adapters / website UI
```

## Runtime goals

- The library should work in Node, modern browsers, and web workers.
- R is never required at runtime.
- Golden fixtures may be generated with R during development.
- Large-data optimizations should be internal and preserve the public API.
