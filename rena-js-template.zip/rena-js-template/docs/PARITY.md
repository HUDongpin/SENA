# Parity status

## Implemented starter coverage

- upper-triangle co-occurrence ordering;
- binary and weighted row co-occurrences;
- moving stanza window basics;
- row-wise sphere normalization;
- endpoint accumulation basics;
- default high-level `ena()` pipeline;
- dependency-free SVD/PCA starter;
- least-squares node position starter.

## Known parity gaps to close

- exhaustive `ref_window_df` edge cases, especially forward windows and `Inf` combinations;
- exact `Conversation` window behavior;
- full metadata inclusion rules from `ENAdata$add.metadata`;
- exact trajectory object shape for `AccumulatedTrajectory` and `SeparateTrajectory`;
- R `prcomp` sign/orientation parity;
- projection into an existing rotation set;
- means, regression, generalized, and spherical rotations;
- directed ENA node positions;
- statistical tests and writeup helpers;
- complete plotting API parity.

Update this file whenever a feature reaches golden-test parity.
