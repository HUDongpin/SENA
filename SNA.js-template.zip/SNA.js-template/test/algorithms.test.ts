import { describe, expect, it } from "vitest";
import { components, degree, denseGraphToMatrix, gden, geodist, makeDenseGraph, nties } from "../src";

describe("graph normalization", () => {
  it("normalizes a one-based edge list when requested", () => {
    const graph = makeDenseGraph({ order: 3, indexBase: 1, edges: [[1, 2], [2, 3]] }, { mode: "digraph" });
    expect(denseGraphToMatrix(graph)).toEqual([
      [0, 1, 0],
      [0, 0, 1],
      [0, 0, 0],
    ]);
  });

  it("symmetrizes undirected matrix inputs by weak ties", () => {
    const graph = makeDenseGraph(
      [
        [0, 1],
        [0, 0],
      ],
      { mode: "graph" },
    );
    expect(denseGraphToMatrix(graph)).toEqual([
      [0, 1],
      [1, 0],
    ]);
  });
});

describe("density", () => {
  it("counts ties and density for a directed path", () => {
    const graph = [
      [0, 1, 0],
      [0, 0, 1],
      [0, 0, 0],
    ];
    expect(nties(graph, { mode: "digraph" })).toBe(2);
    expect(gden(graph, { mode: "digraph" })).toBeCloseTo(1 / 3);
  });

  it("counts an undirected triangle as density 1", () => {
    const triangle = [
      [0, 1, 1],
      [1, 0, 1],
      [1, 1, 0],
    ];
    expect(nties(triangle, { mode: "graph" })).toBe(3);
    expect(gden(triangle, { mode: "graph" })).toBe(1);
  });
});

describe("degree", () => {
  const path = [
    [0, 1, 0],
    [0, 0, 1],
    [0, 0, 0],
  ];

  it("computes directed outdegree", () => {
    expect(degree(path, { mode: "digraph", cmode: "outdegree" })).toEqual([1, 1, 0]);
  });

  it("computes directed indegree", () => {
    expect(degree(path, { mode: "digraph", cmode: "indegree" })).toEqual([0, 1, 1]);
  });

  it("computes directed total degree", () => {
    expect(degree(path, { mode: "digraph", cmode: "total" })).toEqual([1, 2, 1]);
  });
});

describe("geodist", () => {
  it("computes directed shortest-path distances and path counts", () => {
    const result = geodist(
      [
        [0, 1, 0],
        [0, 0, 1],
        [0, 0, 0],
      ],
      { mode: "digraph" },
    );

    expect(result.distances).toEqual([
      [0, 1, 2],
      [Number.POSITIVE_INFINITY, 0, 1],
      [Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY, 0],
    ]);
    expect(result.counts).toEqual([
      [1, 1, 1],
      [0, 1, 1],
      [0, 0, 1],
    ]);
  });
});

describe("components", () => {
  it("finds weak connectivity in a directed path", () => {
    const result = components(
      [
        [0, 1, 0],
        [0, 0, 1],
        [0, 0, 0],
      ],
      { mode: "digraph", connected: "weak" },
    );
    expect(result.count).toBe(1);
    expect(result.sizes).toEqual([3]);
  });

  it("finds strong components in a directed path", () => {
    const result = components(
      [
        [0, 1, 0],
        [0, 0, 1],
        [0, 0, 0],
      ],
      { mode: "digraph", connected: "strong" },
    );
    expect(result.count).toBe(3);
    expect([...result.sizes].sort()).toEqual([1, 1, 1]);
  });
});
