export type {
  ComponentResult,
  DenseGraph,
  EdgeListInput,
  EdgeTuple,
  GeodistResult,
  GraphInput,
  GraphMode,
  GraphOptions,
  MatrixLike,
} from "./core/types";

export { createNumberMatrix, toNestedMatrix } from "./core/matrix";
export { denseGraphToMatrix, hasTie, isDenseGraph, isEdgeListInput, makeDenseGraph, neighbors, tieWeight } from "./core/graph";
export { components, isConnected } from "./algorithms/components";
export type { ComponentsOptions } from "./algorithms/components";
export { degree } from "./algorithms/degree";
export type { DegreeMode, DegreeOptions } from "./algorithms/degree";
export { gden, nties } from "./algorithms/density";
export { geodist } from "./algorithms/geodist";
export type { GeodistOptions } from "./algorithms/geodist";
export { snaR } from "./compat/rNames";
