import { components, isConnected } from "../algorithms/components";
import { degree } from "../algorithms/degree";
import { gden, nties } from "../algorithms/density";
import { geodist } from "../algorithms/geodist";

export const snaR = {
  components,
  degree,
  gden,
  geodist,
  nties,
  "is.connected": isConnected,
} as const;
