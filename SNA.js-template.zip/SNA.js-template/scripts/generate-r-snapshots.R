# Generate small R `sna` parity snapshots.
# Usage:
#   R CMD INSTALL reference/r-sna-2.8
#   Rscript scripts/generate-r-snapshots.R

if (!requireNamespace("sna", quietly = TRUE)) {
  stop("The R package `sna` is not installed. Run: R CMD INSTALL reference/r-sna-2.8")
}

json_num <- function(x) {
  if (is.nan(x)) return("null")
  if (is.infinite(x)) return(ifelse(x > 0, "\"Inf\"", "\"-Inf\""))
  format(x, scientific = FALSE, digits = 16)
}
json_vec <- function(x) paste0("[", paste(vapply(x, json_num, character(1)), collapse = ","), "]")
json_mat <- function(m) paste0("[", paste(apply(m, 1, json_vec), collapse = ","), "]")

path3 <- matrix(c(
  0, 1, 0,
  0, 0, 1,
  0, 0, 0
), byrow = TRUE, nrow = 3)

geo <- sna::geodist(path3)

out <- paste0(
  "{\n",
  "  \"directedPath3\": {\n",
  "    \"gden\": ", json_num(sna::gden(path3, mode = "digraph")), ",\n",
  "    \"degreeOut\": ", json_vec(sna::degree(path3, cmode = "outdegree")), ",\n",
  "    \"geodist\": ", json_mat(geo$gdist), "\n",
  "  }\n",
  "}\n"
)

if (!dir.exists("test/fixtures")) dir.create("test/fixtures", recursive = TRUE)
writeLines(out, "test/fixtures/r-snapshots.json")
cat("Wrote test/fixtures/r-snapshots.json\n")
