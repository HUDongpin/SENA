"use client";

import Link from "next/link";
import { Building2, Chrome, KeyRound, LockKeyhole, Mail, ShieldCheck, UsersRound } from "lucide-react";
import { NavBar } from "@/components/NavBar";
import { NetworkVisualization } from "@/components/NetworkVisualization";
import { Button, Card } from "@/components/Primitives";
import { useLanguage } from "@/components/LanguageProvider";

export default function LoginPage() {
  const { copy } = useLanguage();

  return (
    <main className="min-h-screen overflow-hidden">
      <NavBar />
      <section className="relative px-4 py-16 sm:px-6 lg:px-8">
        <div className="absolute inset-0 -z-10 bg-sena-radial" />
        <div className="sena-grid absolute inset-0 -z-10 animate-gridMove opacity-20" />
        <div className="mx-auto grid max-w-7xl items-center gap-8 lg:grid-cols-[1fr_0.9fr]">
          <div className="relative hidden lg:block">
            <div className="absolute -inset-8 -z-10 rounded-[3rem] bg-gradient-to-br from-cyanGlow/20 via-violetGlow/20 to-magentaGlow/20 blur-3xl" />
            <NetworkVisualization compact />
            <div className="mt-5 grid grid-cols-3 gap-4">
              {[
                { icon: ShieldCheck, label: "Enterprise SSO ready" },
                { icon: UsersRound, label: "Role-based research team access" },
                { icon: LockKeyhole, label: "Audit-ready project logs" }
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <Card key={item.label} className="rounded-2xl p-4">
                    <Icon className="h-5 w-5 text-cyanGlow" />
                    <p className="mt-3 text-sm font-bold leading-5 text-foreground/78">{item.label}</p>
                  </Card>
                );
              })}
            </div>
          </div>

          <Card className="mx-auto w-full max-w-xl rounded-[2.5rem] p-6 sm:p-8">
            <div className="mb-8">
              <div className="text-xs font-black uppercase tracking-[0.24em] text-cyanGlow">Enterprise access</div>
              <h1 className="mt-3 text-4xl font-black tracking-tight text-foreground">{copy.nav.login} to SENA</h1>
              <p className="mt-3 text-base leading-7 text-muted">Secure access for research teams, labs, and institutions.</p>
            </div>

            <form className="grid gap-5" onSubmit={(event) => event.preventDefault()}>
              {/* Connect this form to your authentication provider, enterprise SSO, or internal identity service. */}
              <label className="grid gap-2 text-sm font-bold text-foreground/80">
                {copy.labels.email}
                <span className="relative">
                  <Mail className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" />
                  <input
                    type="email"
                    required
                    placeholder="researcher@university.edu"
                    className="w-full rounded-2xl border border-cardBorder/55 bg-background/45 px-12 py-4 text-foreground outline-none transition placeholder:text-muted/70 focus:border-cyanGlow"
                  />
                </span>
              </label>

              <label className="grid gap-2 text-sm font-bold text-foreground/80">
                {copy.labels.password}
                <span className="relative">
                  <KeyRound className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••••••"
                    className="w-full rounded-2xl border border-cardBorder/55 bg-background/45 px-12 py-4 text-foreground outline-none transition placeholder:text-muted/70 focus:border-cyanGlow"
                  />
                </span>
              </label>

              <div className="flex flex-wrap items-center justify-between gap-3 text-sm">
                <label className="flex items-center gap-2 font-semibold text-muted">
                  <input type="checkbox" className="h-4 w-4 rounded border-cardBorder bg-background" />
                  {copy.labels.remember}
                </label>
                <a href="#" className="font-bold text-cyanGlow hover:underline">{copy.labels.forgot}</a>
              </div>

              <Button type="submit" size="lg" className="w-full">{copy.nav.login}</Button>
            </form>

            <div className="my-6 flex items-center gap-3 text-xs font-black uppercase tracking-[0.22em] text-muted">
              <div className="h-px flex-1 bg-cardBorder/55" /> Secure sign-in options <div className="h-px flex-1 bg-cardBorder/55" />
            </div>

            <div className="grid gap-3">
              <Button variant="secondary" className="w-full"><Building2 className="h-5 w-5" />{copy.labels.sso}</Button>
              <Button variant="secondary" className="w-full"><ShieldCheck className="h-5 w-5" />{copy.labels.orcid}</Button>
              <Button variant="secondary" className="w-full"><Chrome className="h-5 w-5" />{copy.labels.google}</Button>
            </div>

            <p className="mt-8 text-center text-sm text-muted">
              {copy.labels.noAccount} <Link href="/register" className="font-black text-cyanGlow hover:underline">{copy.nav.register}</Link>
            </p>
          </Card>
        </div>
      </section>
    </main>
  );
}
