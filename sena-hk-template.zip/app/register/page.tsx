"use client";

import Link from "next/link";
import { Building2, Chrome, FlaskConical, LockKeyhole, Mail, ShieldCheck, Sparkles, UserRound, UsersRound } from "lucide-react";
import { NavBar } from "@/components/NavBar";
import { Button, Card } from "@/components/Primitives";
import { useLanguage } from "@/components/LanguageProvider";

const plans = [
  { title: "Individual Researcher", icon: UserRound, text: "For graduate students and independent research projects." },
  { title: "Research Lab", icon: FlaskConical, text: "For coding teams, grant projects, and shared datasets." },
  { title: "Enterprise / Institution", icon: Building2, text: "For SSO, role policies, audit logs, and institutional governance." }
];

function TeamNetworkVisual() {
  return (
    <Card className="relative overflow-hidden rounded-[2.5rem] p-8">
      <div className="absolute inset-0 bg-sena-radial opacity-70" />
      <div className="sena-grid absolute inset-0 animate-gridMove opacity-20" />
      <div className="relative z-10">
        <div className="text-xs font-black uppercase tracking-[0.24em] text-cyanGlow">Secure workspace</div>
        <h2 className="mt-3 text-3xl font-black tracking-tight text-foreground">Invite your research team into a shared SENA project.</h2>
        <p className="mt-4 text-base leading-8 text-muted">Manage coding roles, audit changes, run comparative network analyses, and export reproducible reports.</p>
        <svg viewBox="0 0 460 300" className="mt-6 h-72 w-full" aria-label="Research team network visual">
          <defs>
            <linearGradient id="team-grad" x1="0" x2="460" y1="0" y2="300" gradientUnits="userSpaceOnUse">
              <stop stopColor="rgb(var(--glow-cyan))" />
              <stop offset="0.55" stopColor="rgb(var(--glow-violet))" />
              <stop offset="1" stopColor="rgb(var(--glow-magenta))" />
            </linearGradient>
          </defs>
          {[
            "M80 70 L210 52 L340 86 L388 210 L224 246 L96 205 Z",
            "M80 70 L224 246",
            "M210 52 L388 210",
            "M96 205 L340 86",
            "M210 52 L224 246"
          ].map((d) => <path key={d} d={d} fill="none" stroke="url(#team-grad)" strokeWidth="2" opacity="0.45" />)}
          {[
            [80, 70, "PI"], [210, 52, "Coder"], [340, 86, "Lab"], [388, 210, "Admin"], [224, 246, "Reviewer"], [96, 205, "Student"]
          ].map(([x, y, label]) => (
            <g key={label as string}>
              <circle cx={x as number} cy={y as number} r="22" fill="rgb(var(--card) / 0.72)" stroke="url(#team-grad)" strokeWidth="3" />
              <text x={x as number} y={(y as number) + 5} textAnchor="middle" fill="rgb(var(--foreground))" fontSize="11" fontWeight="800">{label as string}</text>
            </g>
          ))}
        </svg>
      </div>
    </Card>
  );
}

export default function RegisterPage() {
  const { copy } = useLanguage();

  return (
    <main className="min-h-screen overflow-hidden">
      <NavBar />
      <section className="relative px-4 py-16 sm:px-6 lg:px-8">
        <div className="absolute inset-0 -z-10 bg-sena-radial" />
        <div className="sena-grid absolute inset-0 -z-10 animate-gridMove opacity-20" />
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.95fr_1fr]">
          <Card className="rounded-[2.5rem] p-6 sm:p-8">
            <div className="mb-8">
              <div className="text-xs font-black uppercase tracking-[0.24em] text-cyanGlow">Create account</div>
              <h1 className="mt-3 text-4xl font-black tracking-tight text-foreground">{copy.nav.register} for SENA.HK</h1>
              <p className="mt-3 text-base leading-7 text-muted">Start an individual project, research lab workspace, or institution-ready deployment.</p>
            </div>

            <form className="grid gap-5" onSubmit={(event) => event.preventDefault()}>
              {/* Connect this registration flow to backend authentication, invitation workflows, and enterprise provisioning. */}
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="grid gap-2 text-sm font-bold text-foreground/80">
                  {copy.labels.fullName}
                  <span className="relative">
                    <UserRound className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" />
                    <input required placeholder="Dr. Ada Chen" className="w-full rounded-2xl border border-cardBorder/55 bg-background/45 px-12 py-4 text-foreground outline-none focus:border-cyanGlow" />
                  </span>
                </label>
                <label className="grid gap-2 text-sm font-bold text-foreground/80">
                  {copy.labels.email}
                  <span className="relative">
                    <Mail className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" />
                    <input required type="email" placeholder="researcher@university.edu" className="w-full rounded-2xl border border-cardBorder/55 bg-background/45 px-12 py-4 text-foreground outline-none focus:border-cyanGlow" />
                  </span>
                </label>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <label className="grid gap-2 text-sm font-bold text-foreground/80">
                  {copy.labels.organization}
                  <input required placeholder="University / Lab" className="w-full rounded-2xl border border-cardBorder/55 bg-background/45 px-4 py-4 text-foreground outline-none focus:border-cyanGlow" />
                </label>
                <label className="grid gap-2 text-sm font-bold text-foreground/80">
                  {copy.labels.role}
                  <select className="w-full rounded-2xl border border-cardBorder/55 bg-background/45 px-4 py-4 text-foreground outline-none focus:border-cyanGlow">
                    <option>Researcher</option>
                    <option>Educator</option>
                    <option>Lab Admin</option>
                    <option>Student</option>
                    <option>Enterprise</option>
                  </select>
                </label>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <label className="grid gap-2 text-sm font-bold text-foreground/80">
                  {copy.labels.password}
                  <span className="relative">
                    <LockKeyhole className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" />
                    <input required type="password" placeholder="••••••••••••" className="w-full rounded-2xl border border-cardBorder/55 bg-background/45 px-12 py-4 text-foreground outline-none focus:border-cyanGlow" />
                  </span>
                </label>
                <label className="grid gap-2 text-sm font-bold text-foreground/80">
                  {copy.labels.confirmPassword}
                  <input required type="password" placeholder="••••••••••••" className="w-full rounded-2xl border border-cardBorder/55 bg-background/45 px-4 py-4 text-foreground outline-none focus:border-cyanGlow" />
                </label>
              </div>

              <label className="grid gap-2 text-sm font-bold text-foreground/80">
                {copy.labels.inviteCode}
                <input placeholder="SENA-LAB-2026" className="w-full rounded-2xl border border-cardBorder/55 bg-background/45 px-4 py-4 text-foreground outline-none focus:border-cyanGlow" />
              </label>

              <div>
                <div className="mb-3 text-sm font-black text-foreground/80">Plan</div>
                <div className="grid gap-3 md:grid-cols-3">
                  {plans.map((plan, index) => {
                    const Icon = plan.icon;
                    return (
                      <label key={plan.title} className="cursor-pointer rounded-3xl border border-cardBorder/45 bg-background/35 p-4 transition hover:border-cyanGlow/45 hover:bg-card/55">
                        <input type="radio" name="plan" defaultChecked={index === 1} className="sr-only" />
                        <Icon className="h-5 w-5 text-cyanGlow" />
                        <div className="mt-3 text-sm font-black text-foreground">{plan.title}</div>
                        <p className="mt-2 text-xs leading-5 text-muted">{plan.text}</p>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="grid gap-3 text-sm text-muted">
                <label className="flex gap-3"><input required type="checkbox" className="mt-1 h-4 w-4" /> I agree to the Terms and responsible AI use policy.</label>
                <label className="flex gap-3"><input type="checkbox" className="mt-1 h-4 w-4" /> Receive product updates and research-platform announcements.</label>
              </div>

              <Button type="submit" size="lg" className="w-full"><Sparkles className="h-5 w-5" />{copy.nav.register}</Button>
            </form>

            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              <Button variant="secondary" className="w-full"><ShieldCheck className="h-5 w-5" />SSO</Button>
              <Button variant="secondary" className="w-full"><ShieldCheck className="h-5 w-5" />ORCID</Button>
              <Button variant="secondary" className="w-full"><Chrome className="h-5 w-5" />Google</Button>
            </div>

            <p className="mt-8 text-center text-sm text-muted">
              {copy.labels.already} <Link href="/login" className="font-black text-cyanGlow hover:underline">{copy.nav.login}</Link>
            </p>
          </Card>

          <div className="hidden lg:block">
            <TeamNetworkVisual />
          </div>
        </div>
      </section>
    </main>
  );
}
