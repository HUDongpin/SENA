# SENA.HK Website Template

SENA — Social-Epistemic Nexus Analytics — is a modern research-platform template for social-epistemic network analysis, discourse analytics, SNA + ENA workflows, AI-assisted interpretation, and reproducible reporting.

## Stack

- Next.js App Router
- TypeScript
- Tailwind CSS
- Framer Motion
- lucide-react icons
- LocalStorage-based day/night theme and ENG / 繁 / 简 language preference
- No backend required yet; mock data and placeholder comments are included where authentication, file upload, analysis engines, and reporting APIs should connect.

## Run locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Build

```bash
npm run build
npm run start
```

The template was build-tested in the sandbox with Next.js 14.2.x. The generated routes are `/`, `/_not-found`, `/login`, and `/register`.

## Main routes

- `/` — SENA landing page with platform, method, workspace, research cases, analytics, ethics, and docs sections
- `/login` — enterprise-level login page with SSO placeholders
- `/register` — enterprise-level registration page with plan selector

## Suggested next development tasks

1. Connect `/login` and `/register` to an identity provider such as institutional SSO, ORCID, Google, or a custom auth backend.
2. Replace mock dashboard data with project APIs for imports, codebooks, ENA/SNA jobs, SENA fusion jobs, and reports.
3. Add backend services for file upload, anonymization, coding workflows, network computation, figure generation, and audit logs.
4. Expand the i18n dictionary with full translations for all module card descriptions.
5. Add tests for forms, accessibility, theme persistence, and language persistence.
